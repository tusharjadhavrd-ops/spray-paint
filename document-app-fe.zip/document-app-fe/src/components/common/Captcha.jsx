import { useEffect, useRef, useState, useCallback } from 'react';
import {
  Box,
  Stack,
  TextField,
  IconButton,
  Tooltip,
  Typography,
  useTheme,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no ambiguous chars (0/O, 1/I)
const LENGTH = 5;

const randomCode = () =>
  Array.from({ length: LENGTH }, () =>
    CHARS.charAt(Math.floor(Math.random() * CHARS.length))
  ).join('');

/**
 * Self-contained, dependency-free captcha. Draws a distorted code on a canvas
 * and validates user input locally. Calls `onValidChange(boolean)` whenever the
 * match status changes — the parent just tracks a boolean.
 *
 * (For production, swap this for a real service like reCAPTCHA / hCaptcha.)
 */
const Captcha = ({ onValidChange }) => {
  const theme = useTheme();
  const canvasRef = useRef(null);
  const [code, setCode] = useState(randomCode);
  const [input, setInput] = useState('');

  const isDark = theme.palette.mode === 'dark';
  const ink = isDark ? '#ffffff' : '#000000';
  const surface = isDark ? '#000000' : '#ffffff';

  const draw = useCallback(
    (value) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const { width, height } = canvas;

      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = surface;
      ctx.fillRect(0, 0, width, height);

      // noise lines
      ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.25)';
      for (let i = 0; i < 6; i += 1) {
        ctx.beginPath();
        ctx.moveTo(Math.random() * width, Math.random() * height);
        ctx.lineTo(Math.random() * width, Math.random() * height);
        ctx.stroke();
      }

      // characters
      ctx.fillStyle = ink;
      ctx.textBaseline = 'middle';
      const step = width / (value.length + 1);
      value.split('').forEach((ch, i) => {
        const fontSize = 24 + Math.floor(Math.random() * 8);
        ctx.font = `bold ${fontSize}px "Courier New", monospace`;
        const x = step * (i + 1);
        const y = height / 2 + (Math.random() * 8 - 4);
        const angle = (Math.random() - 0.5) * 0.5;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.fillText(ch, -fontSize / 3, 0);
        ctx.restore();
      });

      // noise dots
      for (let i = 0; i < 40; i += 1) {
        ctx.fillStyle = isDark ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)';
        ctx.beginPath();
        ctx.arc(Math.random() * width, Math.random() * height, 1, 0, Math.PI * 2);
        ctx.fill();
      }
    },
    [ink, surface, isDark]
  );

  const refresh = useCallback(() => {
    const next = randomCode();
    setCode(next);
    setInput('');
  }, []);

  useEffect(() => {
    draw(code);
  }, [code, draw]);

  const isValid = input.length === LENGTH && input.toUpperCase() === code;

  useEffect(() => {
    onValidChange?.(isValid);
  }, [isValid, onValidChange]);

  return (
    <Box>
      <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5, display: 'block' }}>
        Captcha verification
      </Typography>
      <Stack direction="row" spacing={1.5} alignItems="center">
        <Box
          sx={{
            border: '1px solid',
            borderColor: 'divider',
            borderRadius: 1,
            overflow: 'hidden',
            lineHeight: 0,
          }}
        >
          <canvas ref={canvasRef} width={150} height={52} aria-label="captcha image" />
        </Box>
        <Tooltip title="Refresh captcha">
          <IconButton onClick={refresh} aria-label="refresh captcha">
            <RefreshIcon />
          </IconButton>
        </Tooltip>
      </Stack>

      <TextField
        sx={{ mt: 1.5 }}
        label="Enter the code above"
        value={input}
        onChange={(e) => setInput(e.target.value.toUpperCase().slice(0, LENGTH))}
        inputProps={{ style: { letterSpacing: '0.3em' }, maxLength: LENGTH }}
        error={input.length === LENGTH && !isValid}
        helperText={
          input.length === LENGTH && !isValid ? 'Code does not match.' : ' '
        }
        InputProps={{
          endAdornment: isValid ? (
            <CheckCircleIcon color="primary" fontSize="small" />
          ) : null,
        }}
      />
    </Box>
  );
};

export default Captcha;
