import { useRef } from 'react';
import { Stack, TextField } from '@mui/material';

/**
 * Segmented OTP input. Controlled via `value` (string) + `onChange(string)`.
 * Handles auto-advance, backspace, arrow keys and paste.
 */
const OtpInput = ({ length = 6, value = '', onChange, disabled = false }) => {
  const refs = useRef([]);

  const setChar = (index, char) => {
    const chars = value.split('');
    chars[index] = char;
    // pad to length so indexes line up
    const next = Array.from({ length }, (_, i) => chars[i] || '').join('');
    onChange?.(next.replace(/\s/g, ''));
  };

  const handleChange = (index, e) => {
    const digit = e.target.value.replace(/\D/g, '').slice(-1);
    if (!digit) {
      setChar(index, '');
      return;
    }
    setChar(index, digit);
    if (index < length - 1) refs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace') {
      if (!value[index] && index > 0) {
        refs.current[index - 1]?.focus();
        setChar(index - 1, '');
      } else {
        setChar(index, '');
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      refs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < length - 1) {
      refs.current[index + 1]?.focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length);
    if (!pasted) return;
    onChange?.(pasted);
    const focusIndex = Math.min(pasted.length, length - 1);
    refs.current[focusIndex]?.focus();
  };

  return (
    <Stack direction="row" spacing={{ xs: 0.75, sm: 1 }} sx={{ width: '100%' }}>
      {Array.from({ length }).map((_, i) => (
        <TextField
          key={i}
          inputRef={(el) => (refs.current[i] = el)}
          value={value[i] || ''}
          onChange={(e) => handleChange(i, e)}
          onKeyDown={(e) => handleKeyDown(i, e)}
          onPaste={handlePaste}
          disabled={disabled}
          fullWidth={false}
          inputProps={{
            inputMode: 'numeric',
            maxLength: 1,
            'aria-label': `digit ${i + 1}`,
            style: {
              textAlign: 'center',
              fontSize: '1.4rem',
              fontWeight: 700,
              padding: '12px 0',
            },
          }}
          // Fluid: boxes share the row width and shrink on small screens
          // instead of overflowing, capped so they stay square-ish on desktop.
          sx={{ flex: '1 1 0', minWidth: 0, maxWidth: 56 }}
        />
      ))}
    </Stack>
  );
};

export default OtpInput;
