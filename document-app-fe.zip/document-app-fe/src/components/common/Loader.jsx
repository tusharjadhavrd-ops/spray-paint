import { Backdrop, Box, CircularProgress, Paper, Typography } from '@mui/material';

/**
 * App-wide loader. Use it two ways:
 *   - <Loader open={isLoading} fullScreen label="…" /> blocking overlay (dimmed
 *     + blurred backdrop with a themed card)
 *   - <Loader />                                        inline, centered in its container
 *
 * A single component keeps the loading experience consistent everywhere.
 */
const Loader = ({ open = true, fullScreen = false, label, size = 40, sx }) => {
  if (!open) return null;

  const items = (
    <>
      <CircularProgress size={size} thickness={4} color="inherit" />
      {label ? (
        <Typography variant="body2" fontWeight={600} color="inherit" textAlign="center">
          {label}
        </Typography>
      ) : null}
    </>
  );

  if (fullScreen) {
    return (
      <Backdrop
        open
        sx={{
          zIndex: (theme) => theme.zIndex.modal + 1,
          bgcolor: 'rgba(0, 0, 0, 0.35)',
          backdropFilter: 'blur(4px)',
          ...sx,
        }}
      >
        <Paper
          elevation={8}
          sx={{
            px: 5,
            py: 4,
            minWidth: 220,
            borderRadius: 3,
            color: 'text.primary',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 2,
          }}
        >
          {items}
        </Paper>
      </Backdrop>
    );
  }

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 2,
        width: '100%',
        py: 6,
        color: 'text.primary',
        ...sx,
      }}
    >
      {items}
    </Box>
  );
};

export default Loader;
