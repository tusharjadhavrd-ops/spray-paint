import { Box, Container, Link, Stack, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { ROUTES } from '@constants';

/** App footer shown on authenticated pages (via AppLayout). */
const Footer = () => (
  <Box
    component="footer"
    sx={{
      mt: 'auto',
      borderTop: '1px solid',
      borderColor: 'divider',
      bgcolor: 'background.paper',
    }}
  >
    <Container maxWidth="lg" sx={{ py: 2.5 }}>
      <Stack
        direction={{ xs: 'column', sm: 'row' }}
        spacing={1}
        alignItems="center"
        justifyContent="space-between"
      >
        <Typography variant="body2" color="text.secondary">
          © {new Date().getFullYear()} Document App. All rights reserved.
        </Typography>
        <Link
          component={RouterLink}
          to={ROUTES.TERMS}
          variant="body2"
          color="text.secondary"
          underline="hover"
        >
          Terms & Conditions
        </Link>
      </Stack>
    </Container>
  </Box>
);

export default Footer;
