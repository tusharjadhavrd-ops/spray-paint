import { createTheme, responsiveFontSizes } from '@mui/material/styles';

/**
 * Black & white design system.
 * Light mode = white surfaces, black accents.
 * Dark mode  = black surfaces, white accents.
 * Switch via the `mode` argument so the whole app stays monochrome.
 */
const buildPalette = (mode) =>
  mode === 'dark'
    ? {
        mode: 'dark',
        primary: { main: '#ffffff', contrastText: '#000000' },
        secondary: { main: '#9e9e9e', contrastText: '#000000' },
        background: { default: '#000000', paper: '#0a0a0a' },
        text: { primary: '#ffffff', secondary: '#b0b0b0', disabled: '#6b6b6b' },
        divider: 'rgba(255, 255, 255, 0.12)',
        error: { main: '#ff5252' },
        success: { main: '#9e9e9e' },
      }
    : {
        mode: 'light',
        primary: { main: '#000000', contrastText: '#ffffff' },
        secondary: { main: '#5f5f5f', contrastText: '#ffffff' },
        background: { default: '#f4f4f4', paper: '#ffffff' },
        text: { primary: '#0a0a0a', secondary: '#5f5f5f', disabled: '#9e9e9e' },
        divider: 'rgba(0, 0, 0, 0.12)',
        error: { main: '#d32f2f' },
        success: { main: '#2e2e2e' },
      };

export const createAppTheme = (mode = 'dark') =>
  responsiveFontSizes(
    createTheme({
    palette: buildPalette(mode),
    shape: { borderRadius: 10 },
    typography: {
      fontFamily:
        '"Inter", "Segoe UI", "Roboto", "Helvetica", "Arial", sans-serif',
      h1: { fontWeight: 700, letterSpacing: '-0.02em' },
      h2: { fontWeight: 700, letterSpacing: '-0.02em' },
      h3: { fontWeight: 700 },
      h4: { fontWeight: 700 },
      h5: { fontWeight: 600 },
      h6: { fontWeight: 600 },
      button: { fontWeight: 600, textTransform: 'none' },
    },
    components: {
      MuiButton: {
        defaultProps: { disableElevation: true },
        styleOverrides: {
          root: { borderRadius: 10, paddingBlock: 10, paddingInline: 18 },
        },
      },
      MuiTextField: {
        defaultProps: { variant: 'outlined', fullWidth: true, size: 'medium' },
      },
      MuiPaper: {
        styleOverrides: { root: { backgroundImage: 'none' } },
      },
      MuiAppBar: {
        defaultProps: { elevation: 0, color: 'default' },
      },
    },
    }),
  );

export default createAppTheme;
