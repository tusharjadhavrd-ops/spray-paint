import { createContext, useContext, useMemo, useState, useCallback } from 'react';
import { ThemeProvider, CssBaseline } from '@mui/material';
import { createAppTheme } from './theme';
import { STORAGE_KEYS } from '@constants';

const ColorModeContext = createContext({
  mode: 'light',
  toggleColorMode: () => {},
  setMode: () => {},
});

export const useColorMode = () => useContext(ColorModeContext);

const getInitialMode = () => {
  const saved = localStorage.getItem(STORAGE_KEYS.THEME_MODE);
  if (saved === 'light' || saved === 'dark') return saved;
  return 'light';
};

/**
 * Wraps the app with MUI's ThemeProvider and exposes a Context API
 * for toggling between the black (dark) and white (light) palettes.
 */
export const ColorModeProvider = ({ children }) => {
  const [mode, setModeState] = useState(getInitialMode);

  const setMode = useCallback((next) => {
    setModeState(next);
    localStorage.setItem(STORAGE_KEYS.THEME_MODE, next);
  }, []);

  const toggleColorMode = useCallback(() => {
    setModeState((prev) => {
      const next = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem(STORAGE_KEYS.THEME_MODE, next);
      return next;
    });
  }, []);

  const theme = useMemo(() => createAppTheme(mode), [mode]);
  const value = useMemo(
    () => ({ mode, toggleColorMode, setMode }),
    [mode, toggleColorMode, setMode]
  );

  return (
    <ColorModeContext.Provider value={value}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
};

export default ColorModeContext;
