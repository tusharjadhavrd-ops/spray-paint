import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ROUTES } from '@constants';
import Loader from '@components/common/Loader';
import ProtectedRoute from './ProtectedRoute';
import PublicOnlyRoute from './PublicOnlyRoute';

// Code-split pages for a large-scale app.
const Login = lazy(() => import('@pages/auth/Login'));
const Register = lazy(() => import('@pages/auth/Register'));
const ResetPassword = lazy(() => import('@pages/auth/ResetPassword'));
const CreateDocument = lazy(() => import('@pages/documents/CreateDocument'));
const ViewPrevious = lazy(() => import('@pages/documents/ViewPrevious'));
const Profile = lazy(() => import('@pages/profile/Profile'));
const Terms = lazy(() => import('@pages/legal/Terms'));
const NotFound = lazy(() => import('@pages/NotFound'));

const Fallback = () => <Loader sx={{ minHeight: '100%' }} />;

const AppRoutes = () => (
  <Suspense fallback={<Fallback />}>
    <Routes>
      <Route path={ROUTES.ROOT} element={<Navigate to={ROUTES.CREATE_DOCUMENT} replace />} />

      <Route
        path={ROUTES.LOGIN}
        element={
          <PublicOnlyRoute>
            <Login />
          </PublicOnlyRoute>
        }
      />
      <Route
        path={ROUTES.REGISTER}
        element={
          <PublicOnlyRoute>
            <Register />
          </PublicOnlyRoute>
        }
      />
      <Route
        path={ROUTES.RESET_PASSWORD}
        element={
          <PublicOnlyRoute>
            <ResetPassword />
          </PublicOnlyRoute>
        }
      />

      <Route
        path={ROUTES.CREATE_DOCUMENT}
        element={
          <ProtectedRoute>
            <CreateDocument />
          </ProtectedRoute>
        }
      />
      <Route
        path={ROUTES.DOCUMENTS}
        element={
          <ProtectedRoute>
            <ViewPrevious />
          </ProtectedRoute>
        }
      />
      <Route
        path={ROUTES.PROFILE}
        element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        }
      />
      <Route
        path={ROUTES.TERMS}
        element={
          <ProtectedRoute>
            <Terms />
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<NotFound />} />
    </Routes>
  </Suspense>
);

export default AppRoutes;
