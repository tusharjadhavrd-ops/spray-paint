import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectIsAuthenticated } from '@features/auth/authSlice';
import { ROUTES } from '@constants';

/** Keeps signed-in users away from auth pages (login/register/reset). */
const PublicOnlyRoute = ({ children }) => {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  if (isAuthenticated) return <Navigate to={ROUTES.CREATE_DOCUMENT} replace />;
  return children;
};

export default PublicOnlyRoute;
