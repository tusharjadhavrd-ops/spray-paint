import { Navigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectIsAuthenticated } from '@features/auth/authSlice';
import { ROUTES } from '@constants';

/**
 * Guards private routes. Unauthenticated users are bounced to /login,
 * preserving where they were headed so we can return them post-login.
 */
const ProtectedRoute = ({ children }) => {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} replace state={{ from: location }} />;
  }
  return children;
};

export default ProtectedRoute;
