import { useState } from 'react';
import {
  Typography,
  Card,
  CardContent,
  Stack,
  TextField,
  Button,
  Box,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from '@mui/material';
import NoteAddOutlinedIcon from '@mui/icons-material/NoteAddOutlined';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import PictureAsPdfOutlinedIcon from '@mui/icons-material/PictureAsPdfOutlined';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import EditNoteOutlinedIcon from '@mui/icons-material/EditNoteOutlined';
import SendOutlinedIcon from '@mui/icons-material/SendOutlined';
import AppLayout from '@layouts/AppLayout';
import Loader from '@components/common/Loader';
import { generateDocument, refineDocument } from '@features/documents/documentService';
import { downloadFile } from '@utils/downloadFile';

/**
 * Create document: enter a prompt, generate a PDF, preview it, and either
 * download it or request changes (which fetches an updated document). The
 * generation / refinement / filename are backend-driven (simulated for now).
 */
const CreateDocument = () => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingLabel, setLoadingLabel] = useState('Generating your document…');
  const [doc, setDoc] = useState(null); // { fileName, fileUrl }
  const [error, setError] = useState('');

  const [refineOpen, setRefineOpen] = useState(false);
  const [instructions, setInstructions] = useState('');

  const handleGenerate = async () => {
    if (!prompt.trim() || loading) return;
    setError('');
    setLoadingLabel('Generating your document…');
    setLoading(true);
    try {
      const result = await generateDocument(prompt.trim());
      setDoc(result);
    } catch {
      setError('Something went wrong while generating the document. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefineSubmit = async () => {
    if (!instructions.trim()) return;
    const orders = instructions.trim();
    setRefineOpen(false);
    setError('');
    setLoadingLabel('Applying your changes…');
    setLoading(true);
    try {
      const result = await refineDocument({ prompt: prompt.trim(), instructions: orders });
      if (doc?.fileUrl) URL.revokeObjectURL(doc.fileUrl); // replace the old preview
      setDoc(result);
      setInstructions('');
    } catch {
      setError('Could not apply the changes. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!doc) return;
    try {
      await downloadFile(doc.fileUrl, doc.fileName);
    } catch {
      setError('Could not download the file. Please try again.');
    }
  };

  const handleReset = () => {
    if (doc?.fileUrl) URL.revokeObjectURL(doc.fileUrl); // release the demo blob URL
    setDoc(null);
    setPrompt('');
    setError('');
  };

  return (
    <AppLayout>
      {/* Common app-wide loader, shown while generating or applying changes. */}
      <Loader open={loading} fullScreen label={loadingLabel} />

      {!doc ? (
        <Card variant="outlined">
          <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
            <Stack spacing={2.5} sx={{ width: '100%', maxWidth: 920, mx: 'auto' }}>
              <TextField
                label="What document do you want to create?"
                placeholder="Describe your document in detail…"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                multiline
                fullWidth
                disabled={loading}
                sx={{
                  // ~50% of the viewport height, bounded so it stays sensible.
                  '& .MuiInputBase-root': {
                    alignItems: 'flex-start',
                    height: 'clamp(220px, 50dvh, 600px)',
                  },
                  '& .MuiInputBase-inputMultiline': {
                    height: '100% !important',
                    overflowY: 'auto',
                  },
                }}
              />
              <Box sx={{ display: 'flex', justifyContent: { xs: 'stretch', sm: 'flex-end' } }}>
                <Button
                  variant="contained"
                  size="large"
                  startIcon={<NoteAddOutlinedIcon />}
                  onClick={handleGenerate}
                  disabled={!prompt.trim() || loading}
                  sx={{ width: { xs: '100%', sm: 'auto' } }}
                >
                  Generate document
                </Button>
              </Box>
              {error ? (
                <Typography variant="body2" color="error">
                  {error}
                </Typography>
              ) : null}
            </Stack>
          </CardContent>
        </Card>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2.5} alignItems="stretch">
              {/* Left: file info + actions (room for more options later) */}
              <Stack spacing={1.5} sx={{ width: { xs: '100%', md: 260 }, flexShrink: 0 }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
                  <PictureAsPdfOutlinedIcon color="error" />
                  <Typography variant="subtitle1" fontWeight={700} noWrap>
                    {doc.fileName}
                  </Typography>
                </Stack>
                <Divider />
                <Button
                  fullWidth
                  variant="contained"
                  startIcon={<DownloadOutlinedIcon />}
                  onClick={handleDownload}
                >
                  Download
                </Button>
                <Button
                  fullWidth
                  variant="outlined"
                  startIcon={<EditNoteOutlinedIcon />}
                  onClick={() => setRefineOpen(true)}
                >
                  Request changes
                </Button>
                <Button
                  fullWidth
                  variant="outlined"
                  startIcon={<AutorenewIcon />}
                  onClick={handleReset}
                >
                  Generate another
                </Button>
                {error ? (
                  <Typography variant="body2" color="error">
                    {error}
                  </Typography>
                ) : null}
              </Stack>

              {/* Right: PDF preview */}
              <Box
                component="iframe"
                src={doc.fileUrl}
                title={doc.fileName}
                sx={{
                  flex: 1,
                  minWidth: 0,
                  width: '100%',
                  height: { xs: 'clamp(360px, 55dvh, 680px)', md: 'clamp(460px, 72dvh, 900px)' },
                  border: '1px solid',
                  borderColor: 'divider',
                  borderRadius: 1,
                }}
              />
            </Stack>
          </CardContent>
        </Card>
      )}

      {/* Request changes: collect instructions, then fetch an updated document. */}
      <Dialog
        open={refineOpen}
        onClose={() => setRefineOpen(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Request changes</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Tell us what to change in the document and we will regenerate it.
          </DialogContentText>
          <TextField
            autoFocus
            label="Your instructions"
            placeholder="e.g. Make the tone more formal and add a summary section…"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            multiline
            minRows={4}
            fullWidth
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setRefineOpen(false)}>Cancel</Button>
          <Button
            variant="contained"
            startIcon={<SendOutlinedIcon />}
            onClick={handleRefineSubmit}
            disabled={!instructions.trim()}
          >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </AppLayout>
  );
};

export default CreateDocument;
