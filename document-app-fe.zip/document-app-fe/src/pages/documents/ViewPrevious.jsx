import { useEffect, useRef, useState } from 'react';
import {
  Typography,
  Stack,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Tooltip,
  Menu,
  MenuItem,
  ListItemIcon,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  Snackbar,
} from '@mui/material';
import PictureAsPdfOutlinedIcon from '@mui/icons-material/PictureAsPdfOutlined';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import ShareOutlinedIcon from '@mui/icons-material/ShareOutlined';
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import AppLayout from '@layouts/AppLayout';
import Loader from '@components/common/Loader';
import { listDocuments } from '@features/documents/documentService';
import { downloadFile } from '@utils/downloadFile';

const formatDate = (value) =>
  new Date(value).toLocaleDateString(undefined, {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

/** Previously generated documents, with download / share / delete per row. */
const ViewPrevious = () => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [shareAnchor, setShareAnchor] = useState(null);
  const [shareDoc, setShareDoc] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '' });

  // Keep the latest docs in a ref so unmount cleanup revokes the demo blob URLs.
  const docsRef = useRef([]);
  useEffect(() => {
    docsRef.current = documents;
  }, [documents]);

  useEffect(() => {
    let active = true;
    listDocuments()
      .then((docs) => active && setDocuments(docs))
      .catch(() => active && setError('Could not load your documents. Please try again.'))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, []);

  useEffect(
    () => () => docsRef.current.forEach((doc) => URL.revokeObjectURL(doc.fileUrl)),
    [],
  );

  const notify = (message) => setSnackbar({ open: true, message });

  const handleDownload = async (doc) => {
    try {
      await downloadFile(doc.fileUrl, doc.fileName);
    } catch {
      notify('Could not download the file.');
    }
  };

  const openShare = (event, doc) => {
    setShareAnchor(event.currentTarget);
    setShareDoc(doc);
  };
  const closeShare = () => {
    setShareAnchor(null);
    setShareDoc(null);
  };

  const handleEmailShare = () => {
    if (shareDoc) {
      const subject = encodeURIComponent(`Document: ${shareDoc.fileName}`);
      const body = encodeURIComponent(`Here is the document link:\n${shareDoc.fileUrl}`);
      window.location.href = `mailto:?subject=${subject}&body=${body}`;
    }
    closeShare();
  };

  const handleCopyLink = async () => {
    if (shareDoc) {
      try {
        await navigator.clipboard.writeText(shareDoc.fileUrl);
        notify('Link copied to clipboard.');
      } catch {
        notify('Could not copy the link.');
      }
    }
    closeShare();
  };

  const confirmDelete = () => {
    if (deleteTarget) {
      URL.revokeObjectURL(deleteTarget.fileUrl);
      setDocuments((prev) => prev.filter((doc) => doc.id !== deleteTarget.id));
      notify('Document deleted.');
    }
    setDeleteTarget(null);
  };

  return (
    <AppLayout>
      {loading ? (
        <Loader label="Loading your documents…" />
      ) : error ? (
        <Typography color="error">{error}</Typography>
      ) : documents.length === 0 ? (
        <Paper variant="outlined" sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="body1" color="text.secondary">
            You have no documents yet. Create one from the Create document page.
          </Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper} variant="outlined">
          <Table sx={{ minWidth: 640 }}>
            <TableHead>
              <TableRow sx={{ '& th': { fontWeight: 700 } }}>
                <TableCell sx={{ width: 64 }}>#</TableCell>
                <TableCell>Document name</TableCell>
                <TableCell sx={{ display: { xs: 'none', md: 'table-cell' } }}>
                  PDF file name
                </TableCell>
                <TableCell sx={{ display: { xs: 'none', sm: 'table-cell' } }}>Date</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {documents.map((doc, index) => (
                <TableRow key={doc.id} hover>
                  <TableCell>{index + 1}</TableCell>
                  <TableCell>
                    <Typography variant="body2" fontWeight={600} noWrap>
                      {doc.name}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ display: { xs: 'none', md: 'table-cell' } }}>
                    <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
                      <PictureAsPdfOutlinedIcon color="error" fontSize="small" />
                      <Typography variant="body2" color="text.secondary" noWrap>
                        {doc.fileName}
                      </Typography>
                    </Stack>
                  </TableCell>
                  <TableCell sx={{ display: { xs: 'none', sm: 'table-cell' } }}>
                    {formatDate(doc.date)}
                  </TableCell>
                  <TableCell align="right">
                    <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                      <Tooltip title="Download">
                        <IconButton size="small" onClick={() => handleDownload(doc)}>
                          <DownloadOutlinedIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Share">
                        <IconButton size="small" onClick={(e) => openShare(e, doc)}>
                          <ShareOutlinedIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <IconButton
                          size="small"
                          color="error"
                          onClick={() => setDeleteTarget(doc)}
                        >
                          <DeleteOutlinedIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Share menu: email or copy link. */}
      <Menu anchorEl={shareAnchor} open={Boolean(shareAnchor)} onClose={closeShare}>
        <MenuItem onClick={handleEmailShare}>
          <ListItemIcon>
            <EmailOutlinedIcon fontSize="small" />
          </ListItemIcon>
          Share via email
        </MenuItem>
        <MenuItem onClick={handleCopyLink}>
          <ListItemIcon>
            <ContentCopyIcon fontSize="small" />
          </ListItemIcon>
          Copy link
        </MenuItem>
      </Menu>

      {/* Delete confirmation. */}
      <Dialog open={Boolean(deleteTarget)} onClose={() => setDeleteTarget(null)}>
        <DialogTitle>Delete document?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {deleteTarget?.fileName} will be permanently removed. This cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={confirmDelete}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar((s) => ({ ...s, open: false }))}
        message={snackbar.message}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </AppLayout>
  );
};

export default ViewPrevious;
