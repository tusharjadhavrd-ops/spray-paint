import { useState } from 'react';
import { useSelector } from 'react-redux';
import {
  Typography,
  Card,
  CardContent,
  Stack,
  TextField,
  Button,
  Box,
  Grid,
  Divider,
  IconButton,
  Tooltip,
  InputAdornment,
  Snackbar,
} from '@mui/material';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import GitHubIcon from '@mui/icons-material/GitHub';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import CodeOutlinedIcon from '@mui/icons-material/CodeOutlined';
import LinkOutlinedIcon from '@mui/icons-material/LinkOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import WorkspacePremiumOutlinedIcon from '@mui/icons-material/WorkspacePremiumOutlined';
import SchoolOutlinedIcon from '@mui/icons-material/SchoolOutlined';
import WorkOutlineOutlinedIcon from '@mui/icons-material/WorkOutlineOutlined';
import WorkHistoryOutlinedIcon from '@mui/icons-material/WorkHistoryOutlined';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import SaveOutlinedIcon from '@mui/icons-material/SaveOutlined';
import AppLayout from '@layouts/AppLayout';
import { selectUser } from '@features/auth/authSlice';
import { STORAGE_KEYS } from '@constants';

const newEducation = () => ({ id: crypto.randomUUID(), school: '', year: '', grade: '' });
const newProject = () => ({ id: crypto.randomUUID(), name: '', link: '', description: '' });
const newExperience = () => ({
  id: crypto.randomUUID(),
  company: '',
  role: '',
  from: '',
  to: '',
  details: '',
});

const DEFAULT_PROFILE = {
  name: '',
  phone: '',
  email: '',
  linkedin: '',
  github: '',
  leetcode: '',
  codeforces: '',
  about: '',
  certifications: '',
  education: [],
  experience: [],
  projects: [],
};

/** Load a saved profile, falling back to the signed-in user's basics. */
const loadProfile = (user) => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (raw) {
      const saved = JSON.parse(raw);
      return {
        ...DEFAULT_PROFILE,
        ...saved,
        education: saved.education?.length ? saved.education : [newEducation()],
        experience: saved.experience?.length ? saved.experience : [newExperience()],
        projects: saved.projects?.length ? saved.projects : [newProject()],
      };
    }
  } catch {
    /* ignore corrupt storage */
  }
  return {
    ...DEFAULT_PROFILE,
    name: user?.name || '',
    email: user?.email || '',
    education: [newEducation()],
    experience: [newExperience()],
    projects: [newProject()],
  };
};

const startIcon = (icon) => ({
  input: {
    startAdornment: <InputAdornment position="start">{icon}</InputAdornment>,
  },
});

/** Section card with an icon + title header. */
const Section = ({ icon, title, children, action }) => (
  <Card variant="outlined">
    <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2.5 }}>
        {icon}
        <Typography variant="h6" fontWeight={700} sx={{ flexGrow: 1 }}>
          {title}
        </Typography>
        {action}
      </Stack>
      {children}
    </CardContent>
  </Card>
);

/** Profile / resume editor. Persisted to localStorage for now (backend later). */
const Profile = () => {
  const user = useSelector(selectUser);
  const [profile, setProfile] = useState(() => loadProfile(user));
  const [snackbar, setSnackbar] = useState({ open: false, message: '' });

  const setField = (field) => (e) =>
    setProfile((prev) => ({ ...prev, [field]: e.target.value }));

  const setEducation = (id, field) => (e) =>
    setProfile((prev) => ({
      ...prev,
      education: prev.education.map((row) =>
        row.id === id ? { ...row, [field]: e.target.value } : row,
      ),
    }));
  const addEducation = () =>
    setProfile((prev) => ({ ...prev, education: [...prev.education, newEducation()] }));
  const removeEducation = (id) =>
    setProfile((prev) => ({
      ...prev,
      education: prev.education.filter((row) => row.id !== id),
    }));

  const setProject = (id, field) => (e) =>
    setProfile((prev) => ({
      ...prev,
      projects: prev.projects.map((row) =>
        row.id === id ? { ...row, [field]: e.target.value } : row,
      ),
    }));
  const addProject = () =>
    setProfile((prev) => ({ ...prev, projects: [...prev.projects, newProject()] }));
  const removeProject = (id) =>
    setProfile((prev) => ({
      ...prev,
      projects: prev.projects.filter((row) => row.id !== id),
    }));

  const setExperience = (id, field) => (e) =>
    setProfile((prev) => ({
      ...prev,
      experience: prev.experience.map((row) =>
        row.id === id ? { ...row, [field]: e.target.value } : row,
      ),
    }));
  const addExperience = () =>
    setProfile((prev) => ({ ...prev, experience: [...prev.experience, newExperience()] }));
  const removeExperience = (id) =>
    setProfile((prev) => ({
      ...prev,
      experience: prev.experience.filter((row) => row.id !== id),
    }));

  const handleSave = () => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
      setSnackbar({ open: true, message: 'Profile saved.' });
    } catch {
      setSnackbar({ open: true, message: 'Could not save profile.' });
    }
  };

  return (
    <AppLayout>
      <Stack spacing={3}>
        {/* Personal details */}
        <Section icon={<PersonOutlinedIcon />} title="Personal details">
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                label="Name"
                fullWidth
                value={profile.name}
                onChange={setField('name')}
                slotProps={startIcon(<PersonOutlinedIcon fontSize="small" />)}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                label="Phone number"
                fullWidth
                value={profile.phone}
                onChange={setField('phone')}
                slotProps={startIcon(<PhoneOutlinedIcon fontSize="small" />)}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                label="Email"
                type="email"
                fullWidth
                value={profile.email}
                onChange={setField('email')}
                slotProps={startIcon(<EmailOutlinedIcon fontSize="small" />)}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                label="LinkedIn"
                fullWidth
                value={profile.linkedin}
                onChange={setField('linkedin')}
                slotProps={startIcon(<LinkedInIcon fontSize="small" />)}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                label="GitHub"
                fullWidth
                value={profile.github}
                onChange={setField('github')}
                slotProps={startIcon(<GitHubIcon fontSize="small" />)}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                label="LeetCode"
                fullWidth
                value={profile.leetcode}
                onChange={setField('leetcode')}
                slotProps={startIcon(<CodeOutlinedIcon fontSize="small" />)}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                label="Codeforces"
                fullWidth
                value={profile.codeforces}
                onChange={setField('codeforces')}
                slotProps={startIcon(<CodeOutlinedIcon fontSize="small" />)}
              />
            </Grid>
          </Grid>
        </Section>

        {/* About me */}
        <Section icon={<DescriptionOutlinedIcon />} title="About me">
          <TextField
            placeholder="Write a short summary about yourself…"
            fullWidth
            multiline
            minRows={5}
            value={profile.about}
            onChange={setField('about')}
          />
        </Section>

        {/* Certifications */}
        <Section icon={<WorkspacePremiumOutlinedIcon />} title="Certifications">
          <TextField
            placeholder="List your certifications, one per line…"
            fullWidth
            multiline
            minRows={5}
            value={profile.certifications}
            onChange={setField('certifications')}
          />
        </Section>

        {/* Education */}
        <Section
          icon={<SchoolOutlinedIcon />}
          title="Education"
          action={
            <Button startIcon={<AddOutlinedIcon />} onClick={addEducation}>
              Add education
            </Button>
          }
        >
          {profile.education.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              No education added yet.
            </Typography>
          ) : (
            <Stack spacing={2}>
              {profile.education.map((edu, index) => (
                <Box key={edu.id}>
                  {index > 0 ? <Divider sx={{ mb: 2 }} /> : null}
                  <Stack direction="row" spacing={1} alignItems="flex-start">
                    <Grid container spacing={2} sx={{ flexGrow: 1 }}>
                      <Grid size={{ xs: 12, sm: 6 }}>
                        <TextField
                          label="School / University"
                          fullWidth
                          value={edu.school}
                          onChange={setEducation(edu.id, 'school')}
                        />
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <TextField
                          label="Year"
                          fullWidth
                          value={edu.year}
                          onChange={setEducation(edu.id, 'year')}
                        />
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <TextField
                          label="GPA / %"
                          fullWidth
                          value={edu.grade}
                          onChange={setEducation(edu.id, 'grade')}
                        />
                      </Grid>
                    </Grid>
                    <Tooltip title="Remove">
                      <IconButton
                        color="error"
                        onClick={() => removeEducation(edu.id)}
                        sx={{ mt: 1 }}
                      >
                        <DeleteOutlinedIcon />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                </Box>
              ))}
            </Stack>
          )}
        </Section>

        {/* Experience */}
        <Section
          icon={<WorkHistoryOutlinedIcon />}
          title="Experience"
          action={
            <Button startIcon={<AddOutlinedIcon />} onClick={addExperience}>
              Add experience
            </Button>
          }
        >
          {profile.experience.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              No experience added yet.
            </Typography>
          ) : (
            <Stack spacing={2}>
              {profile.experience.map((exp, index) => (
                <Box key={exp.id}>
                  {index > 0 ? <Divider sx={{ mb: 2 }} /> : null}
                  <Stack direction="row" spacing={1} alignItems="flex-start">
                    <Stack spacing={2} sx={{ flexGrow: 1, minWidth: 0 }}>
                      <Grid container spacing={2}>
                        <Grid size={{ xs: 12, sm: 6 }}>
                          <TextField
                            label="Company"
                            fullWidth
                            value={exp.company}
                            onChange={setExperience(exp.id, 'company')}
                          />
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                          <TextField
                            label="Role"
                            fullWidth
                            value={exp.role}
                            onChange={setExperience(exp.id, 'role')}
                          />
                        </Grid>
                        <Grid size={{ xs: 6, sm: 6 }}>
                          <TextField
                            label="From"
                            placeholder="e.g. Jan 2022"
                            fullWidth
                            value={exp.from}
                            onChange={setExperience(exp.id, 'from')}
                          />
                        </Grid>
                        <Grid size={{ xs: 6, sm: 6 }}>
                          <TextField
                            label="To"
                            placeholder="e.g. Present"
                            fullWidth
                            value={exp.to}
                            onChange={setExperience(exp.id, 'to')}
                          />
                        </Grid>
                      </Grid>
                      <TextField
                        label="Details"
                        fullWidth
                        multiline
                        minRows={3}
                        value={exp.details}
                        onChange={setExperience(exp.id, 'details')}
                      />
                    </Stack>
                    <Tooltip title="Remove">
                      <IconButton
                        color="error"
                        onClick={() => removeExperience(exp.id)}
                        sx={{ mt: 1 }}
                      >
                        <DeleteOutlinedIcon />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                </Box>
              ))}
            </Stack>
          )}
        </Section>

        {/* Projects */}
        <Section
          icon={<WorkOutlineOutlinedIcon />}
          title="Projects"
          action={
            <Button startIcon={<AddOutlinedIcon />} onClick={addProject}>
              Add project
            </Button>
          }
        >
          {profile.projects.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              No projects added yet.
            </Typography>
          ) : (
            <Stack spacing={2}>
              {profile.projects.map((proj, index) => (
                <Box key={proj.id}>
                  {index > 0 ? <Divider sx={{ mb: 2 }} /> : null}
                  <Stack direction="row" spacing={1} alignItems="flex-start">
                    <Stack spacing={2} sx={{ flexGrow: 1, minWidth: 0 }}>
                      <Grid container spacing={2}>
                        <Grid size={{ xs: 12, sm: 6 }}>
                          <TextField
                            label="Project name"
                            fullWidth
                            value={proj.name}
                            onChange={setProject(proj.id, 'name')}
                          />
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                          <TextField
                            label="Link"
                            fullWidth
                            value={proj.link}
                            onChange={setProject(proj.id, 'link')}
                            slotProps={startIcon(<LinkOutlinedIcon fontSize="small" />)}
                          />
                        </Grid>
                      </Grid>
                      <TextField
                        label="Description"
                        fullWidth
                        multiline
                        minRows={2}
                        value={proj.description}
                        onChange={setProject(proj.id, 'description')}
                      />
                    </Stack>
                    <Tooltip title="Remove">
                      <IconButton
                        color="error"
                        onClick={() => removeProject(proj.id)}
                        sx={{ mt: 1 }}
                      >
                        <DeleteOutlinedIcon />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                </Box>
              ))}
            </Stack>
          )}
        </Section>

        <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Button
            variant="contained"
            size="large"
            startIcon={<SaveOutlinedIcon />}
            onClick={handleSave}
            sx={{ width: { xs: '100%', sm: 'auto' } }}
          >
            Save profile
          </Button>
        </Box>
      </Stack>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar((s) => ({ ...s, open: false }))}
        message={snackbar.message}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </AppLayout>
  );
};

export default Profile;
