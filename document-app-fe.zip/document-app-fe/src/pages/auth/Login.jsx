import { useState, useEffect } from 'react';
import { useNavigate, Link as RouterLink, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Stack,
  TextField,
  Button,
  Link,
  Alert,
  Typography,
  Divider,
} from '@mui/material';
import AuthLayout from '@layouts/AuthLayout';
import PasswordField from '@components/common/PasswordField';
import {
  loginUser,
  clearError,
  selectAuthStatus,
  selectAuthError,
  selectIsAuthenticated,
} from '@features/auth/authSlice';
import { ROUTES, isValidEmail, DEMO_USERS } from '@constants';

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  const status = useSelector(selectAuthStatus);
  const serverError = useSelector(selectAuthError);
  const isAuthenticated = useSelector(selectIsAuthenticated);

  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});

  const redirectTo = location.state?.from?.pathname || ROUTES.CREATE_DOCUMENT;

  useEffect(() => {
    if (isAuthenticated) navigate(redirectTo, { replace: true });
  }, [isAuthenticated, navigate, redirectTo]);

  useEffect(() => {
    dispatch(clearError());
  }, [dispatch]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => ({ ...er, [name]: undefined }));
  };

  const validate = () => {
    const next = {};
    if (!form.email) next.email = 'Email is required.';
    else if (!isValidEmail(form.email)) next.email = 'Enter a valid email.';
    if (!form.password) next.password = 'Password is required.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    dispatch(loginUser(form));
  };

  const loading = status === 'loading';

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Sign in to continue to your workspace."
      footer={
        <Typography variant="body2" color="text.secondary" align="center">
          Don&apos;t have an account?{' '}
          <Link component={RouterLink} to={ROUTES.REGISTER} fontWeight={600}>
            Create one
          </Link>
        </Typography>
      }
    >
      <form onSubmit={handleSubmit} noValidate>
        <Stack spacing={2.5}>
          {serverError && <Alert severity="error">{serverError}</Alert>}

          <TextField
            label="Email"
            name="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={handleChange}
            error={Boolean(errors.email)}
            helperText={errors.email}
            autoFocus
          />

          <PasswordField
            name="password"
            label="Password"
            autoComplete="current-password"
            value={form.password}
            onChange={handleChange}
            error={Boolean(errors.password)}
            helperText={errors.password}
          />

          <Stack direction="row" justifyContent="flex-end">
            <Link component={RouterLink} to={ROUTES.RESET_PASSWORD} variant="body2">
              Forgot password?
            </Link>
          </Stack>

          <Button type="submit" variant="contained" size="large" disabled={loading}>
            {loading ? 'Signing in…' : 'Sign in'}
          </Button>

          <Divider>
            <Typography variant="caption" color="text.secondary">
              Demo credentials
            </Typography>
          </Divider>

          <Stack spacing={0.5}>
            {DEMO_USERS.map((u) => (
              <Typography key={u.id} variant="caption" color="text.secondary">
                {u.role}: <b>{u.email}</b> / <b>{u.password}</b>
              </Typography>
            ))}
          </Stack>
        </Stack>
      </form>
    </AuthLayout>
  );
};

export default Login;
