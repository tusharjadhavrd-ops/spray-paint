import { useState, useCallback } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import {
  Stack,
  TextField,
  Button,
  Link,
  Alert,
  Typography,
  FormControlLabel,
  Checkbox,
  Stepper,
  Step,
  StepLabel,
  Box,
} from '@mui/material';
import AuthLayout from '@layouts/AuthLayout';
import PasswordField from '@components/common/PasswordField';
import Captcha from '@components/common/Captcha';
import OtpInput from '@components/common/OtpInput';
import { registerUser } from '@features/auth/authSlice';
import * as authService from '@features/auth/authService';
import { useCountdown } from '@hooks/useCountdown';
import {
  ROUTES,
  isValidEmail,
  isValidPassword,
  PASSWORD_RULE_HINT,
  OTP_LENGTH,
  OTP_RESEND_SECONDS,
} from '@constants';

const STEPS = ['Account details', 'Verify OTP'];

const Register = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { seconds, isActive, start } = useCountdown(OTP_RESEND_SECONDS);

  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState({});
  const [captchaValid, setCaptchaValid] = useState(false);
  const [tncAccepted, setTncAccepted] = useState(false);

  const [otp, setOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => ({ ...er, [name]: undefined }));
  };

  const handleCaptchaValid = useCallback((valid) => setCaptchaValid(valid), []);

  const validateDetails = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Name is required.';
    if (!form.email) next.email = 'Email is required.';
    else if (!isValidEmail(form.email)) next.email = 'Enter a valid email.';
    if (!form.password) next.password = 'Password is required.';
    else if (!isValidPassword(form.password)) next.password = PASSWORD_RULE_HINT;
    if (form.confirmPassword !== form.password)
      next.confirmPassword = 'Passwords do not match.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  /* Step 1 -> send OTP -> Step 2 */
  const handleDetailsSubmit = async (e) => {
    e.preventDefault();
    setFormError('');
    if (!validateDetails()) return;
    if (!captchaValid) {
      setFormError('Please complete the captcha verification.');
      return;
    }
    if (!tncAccepted) {
      setFormError('You must accept the Terms & Conditions to continue.');
      return;
    }
    setBusy(true);
    try {
      await authService.sendOtp({ email: form.email });
      setStep(1);
      start();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  /* Step 2 -> verify OTP -> register -> home */
  const handleVerify = async (e) => {
    e.preventDefault();
    setOtpError('');
    if (otp.length !== OTP_LENGTH) {
      setOtpError(`Enter the ${OTP_LENGTH}-digit code.`);
      return;
    }
    setBusy(true);
    try {
      await authService.verifyOtp({ otp });
      const result = await dispatch(
        registerUser({ name: form.name, email: form.email, password: form.password })
      );
      if (registerUser.fulfilled.match(result)) {
        navigate(ROUTES.CREATE_DOCUMENT, { replace: true });
      } else {
        setOtpError(result.payload || 'Registration failed.');
      }
    } catch (err) {
      setOtpError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const handleResend = async () => {
    if (isActive) return;
    setOtpError('');
    try {
      await authService.sendOtp({ email: form.email });
      start();
    } catch (err) {
      setOtpError(err.message);
    }
  };

  return (
    <AuthLayout
      title="Create account"
      subtitle="Join Document App in two quick steps."
      footer={
        <Typography variant="body2" color="text.secondary" align="center">
          Already have an account?{' '}
          <Link component={RouterLink} to={ROUTES.LOGIN} fontWeight={600}>
            Sign in
          </Link>
        </Typography>
      }
    >
      <Stepper activeStep={step} alternativeLabel sx={{ mb: 3 }}>
        {STEPS.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {step === 0 && (
        <form onSubmit={handleDetailsSubmit} noValidate>
          <Stack spacing={2.5}>
            {formError && <Alert severity="error">{formError}</Alert>}

            <TextField
              label="Full name"
              name="name"
              value={form.name}
              onChange={handleChange}
              error={Boolean(errors.name)}
              helperText={errors.name}
              autoFocus
            />
            <TextField
              label="Email"
              name="email"
              type="email"
              autoComplete="email"
              value={form.email}
              onChange={handleChange}
              error={Boolean(errors.email)}
              helperText={errors.email}
            />
            <PasswordField
              name="password"
              label="Password"
              autoComplete="new-password"
              value={form.password}
              onChange={handleChange}
              error={Boolean(errors.password)}
              helperText={errors.password || PASSWORD_RULE_HINT}
            />
            <PasswordField
              name="confirmPassword"
              label="Confirm password"
              autoComplete="new-password"
              value={form.confirmPassword}
              onChange={handleChange}
              error={Boolean(errors.confirmPassword)}
              helperText={errors.confirmPassword}
            />

            <Captcha onValidChange={handleCaptchaValid} />

            <FormControlLabel
              control={
                <Checkbox
                  checked={tncAccepted}
                  onChange={(e) => setTncAccepted(e.target.checked)}
                />
              }
              label={
                <Typography variant="body2">
                  I agree to the{' '}
                  <Link href="#" onClick={(e) => e.preventDefault()}>
                    Terms &amp; Conditions
                  </Link>{' '}
                  and{' '}
                  <Link href="#" onClick={(e) => e.preventDefault()}>
                    Privacy Policy
                  </Link>
                  .
                </Typography>
              }
            />

            <Button type="submit" variant="contained" size="large" disabled={busy}>
              {busy ? 'Sending OTP…' : 'Continue'}
            </Button>
          </Stack>
        </form>
      )}

      {step === 1 && (
        <form onSubmit={handleVerify} noValidate>
          <Stack spacing={3}>
            <Alert severity="info">
              We sent a {OTP_LENGTH}-digit code to <b>{form.email}</b>. (Demo OTP is
              logged to the browser console.)
            </Alert>

            {otpError && <Alert severity="error">{otpError}</Alert>}

            <Box>
              <Typography variant="body2" sx={{ mb: 1.5 }}>
                Enter verification code
              </Typography>
              <OtpInput
                length={OTP_LENGTH}
                value={otp}
                onChange={setOtp}
                disabled={busy}
              />
            </Box>

            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Button variant="text" onClick={() => setStep(0)} disabled={busy}>
                ← Back
              </Button>
              <Button variant="text" onClick={handleResend} disabled={isActive}>
                {isActive ? `Resend in ${seconds}s` : 'Resend code'}
              </Button>
            </Stack>

            <Button type="submit" variant="contained" size="large" disabled={busy}>
              {busy ? 'Verifying…' : 'Verify & create account'}
            </Button>
          </Stack>
        </form>
      )}
    </AuthLayout>
  );
};

export default Register;
