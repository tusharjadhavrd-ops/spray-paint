import { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import {
  Stack,
  TextField,
  Button,
  Link,
  Alert,
  Typography,
  Stepper,
  Step,
  StepLabel,
  Box,
} from '@mui/material';
import AuthLayout from '@layouts/AuthLayout';
import PasswordField from '@components/common/PasswordField';
import OtpInput from '@components/common/OtpInput';
import * as authService from '@features/auth/authService';
import { useCountdown } from '@hooks/useCountdown';
import {
  ROUTES,
  isValidEmail,
  isValidPassword,
  PASSWORD_RULE_HINT,
  OTP_LENGTH,
  OTP_RESEND_SECONDS,
} from '@constants';

const STEPS = ['Email', 'Verify OTP', 'New password'];

const ResetPassword = () => {
  const navigate = useNavigate();
  const { seconds, isActive, start } = useCountdown(OTP_RESEND_SECONDS);

  const [step, setStep] = useState(0);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [passwords, setPasswords] = useState({ password: '', confirm: '' });

  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  /* Step 1: email -> send OTP */
  const handleSendOtp = async (e) => {
    e.preventDefault();
    setError('');
    if (!email) return setError('Email is required.');
    if (!isValidEmail(email)) return setError('Enter a valid email.');
    setBusy(true);
    try {
      await authService.sendOtp({ email });
      setStep(1);
      start();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  /* Step 2: verify OTP */
  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    setError('');
    if (otp.length !== OTP_LENGTH) {
      return setError(`Enter the ${OTP_LENGTH}-digit code.`);
    }
    setBusy(true);
    try {
      await authService.verifyOtp({ otp });
      setStep(2);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  /* Step 3: set new password */
  const handleReset = async (e) => {
    e.preventDefault();
    setError('');
    if (!isValidPassword(passwords.password)) return setError(PASSWORD_RULE_HINT);
    if (passwords.password !== passwords.confirm)
      return setError('Passwords do not match.');
    setBusy(true);
    try {
      await authService.resetPassword({ email, password: passwords.password });
      setDone(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const handleResend = async () => {
    if (isActive) return;
    setError('');
    try {
      await authService.sendOtp({ email });
      start();
    } catch (err) {
      setError(err.message);
    }
  };

  if (done) {
    return (
      <AuthLayout title="Password updated" subtitle="You're all set.">
        <Stack spacing={3}>
          <Alert severity="success">
            Your password has been reset successfully.
          </Alert>
          <Button
            variant="contained"
            size="large"
            onClick={() => navigate(ROUTES.LOGIN)}
          >
            Back to sign in
          </Button>
        </Stack>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      title="Reset password"
      subtitle="We'll verify your identity with a one-time code."
      footer={
        <Typography variant="body2" color="text.secondary" align="center">
          Remembered it?{' '}
          <Link component={RouterLink} to={ROUTES.LOGIN} fontWeight={600}>
            Sign in
          </Link>
        </Typography>
      }
    >
      <Stepper activeStep={step} alternativeLabel sx={{ mb: 3 }}>
        {STEPS.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {step === 0 && (
        <form onSubmit={handleSendOtp} noValidate>
          <Stack spacing={2.5}>
            <TextField
              label="Email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoFocus
            />
            <Button type="submit" variant="contained" size="large" disabled={busy}>
              {busy ? 'Sending OTP…' : 'Send OTP'}
            </Button>
          </Stack>
        </form>
      )}

      {step === 1 && (
        <form onSubmit={handleVerifyOtp} noValidate>
          <Stack spacing={3}>
            <Alert severity="info">
              Enter the {OTP_LENGTH}-digit code sent to <b>{email}</b>. (Demo OTP is
              logged to the browser console.)
            </Alert>
            <Box>
              <Typography variant="body2" sx={{ mb: 1.5 }}>
                Verification code
              </Typography>
              <OtpInput length={OTP_LENGTH} value={otp} onChange={setOtp} disabled={busy} />
            </Box>
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Button variant="text" onClick={() => setStep(0)} disabled={busy}>
                ← Back
              </Button>
              <Button variant="text" onClick={handleResend} disabled={isActive}>
                {isActive ? `Resend in ${seconds}s` : 'Resend code'}
              </Button>
            </Stack>
            <Button type="submit" variant="contained" size="large" disabled={busy}>
              {busy ? 'Verifying…' : 'Verify OTP'}
            </Button>
          </Stack>
        </form>
      )}

      {step === 2 && (
        <form onSubmit={handleReset} noValidate>
          <Stack spacing={2.5}>
            <PasswordField
              label="New password"
              autoComplete="new-password"
              value={passwords.password}
              onChange={(e) =>
                setPasswords((p) => ({ ...p, password: e.target.value }))
              }
              helperText={PASSWORD_RULE_HINT}
            />
            <PasswordField
              label="Confirm new password"
              autoComplete="new-password"
              value={passwords.confirm}
              onChange={(e) =>
                setPasswords((p) => ({ ...p, confirm: e.target.value }))
              }
            />
            <Button type="submit" variant="contained" size="large" disabled={busy}>
              {busy ? 'Updating…' : 'Update password'}
            </Button>
          </Stack>
        </form>
      )}
    </AuthLayout>
  );
};

export default ResetPassword;
