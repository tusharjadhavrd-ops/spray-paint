import { Typography, Card, CardContent, Stack } from '@mui/material';
import AppLayout from '@layouts/AppLayout';

const SECTIONS = [
  {
    heading: '1. Acceptance of terms',
    body: 'By accessing and using Document App you agree to be bound by these terms and conditions. If you do not agree, please discontinue use of the application.',
  },
  {
    heading: '2. Use of the service',
    body: 'You are responsible for the documents you create, upload and share. Do not use the service for any unlawful purpose or in a way that infringes the rights of others.',
  },
  {
    heading: '3. Privacy',
    body: 'We handle your data in line with our privacy practices. Documents you generate remain yours; we do not share them without your consent.',
  },
  {
    heading: '4. Liability',
    body: 'The service is provided on an "as is" basis. To the extent permitted by law, we are not liable for any loss arising from your use of the application.',
  },
];

/** Placeholder Terms & Conditions page (linked from the footer). */
const Terms = () => (
  <AppLayout>
    <Typography variant="h4" fontWeight={800} sx={{ mb: 3 }}>
      Terms & Conditions
    </Typography>

    <Card variant="outlined">
      <CardContent>
        <Stack spacing={3}>
          {SECTIONS.map((section) => (
            <Stack key={section.heading} spacing={0.5}>
              <Typography variant="subtitle1" fontWeight={700}>
                {section.heading}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {section.body}
              </Typography>
            </Stack>
          ))}
        </Stack>
      </CardContent>
    </Card>
  </AppLayout>
);

export default Terms;
