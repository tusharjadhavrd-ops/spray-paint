import { useNavigate } from 'react-router-dom';
import { Box, Typography, Button, Stack } from '@mui/material';
import { ROUTES } from '@constants';

const NotFound = () => {
  const navigate = useNavigate();
  return (
    <Box
      sx={{
        minHeight: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'background.default',
        textAlign: 'center',
        p: 3,
      }}
    >
      <Stack spacing={2} alignItems="center">
        <Typography variant="h1" fontWeight={900} sx={{ fontSize: { xs: 80, sm: 120 } }}>
          404
        </Typography>
        <Typography variant="h6" color="text.secondary">
          The page you&apos;re looking for doesn&apos;t exist.
        </Typography>
        <Button variant="contained" onClick={() => navigate(ROUTES.CREATE_DOCUMENT)}>
          Back to app
        </Button>
      </Stack>
    </Box>
  );
};

export default NotFound;
