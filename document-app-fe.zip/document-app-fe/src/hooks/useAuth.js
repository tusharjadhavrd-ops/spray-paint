import { useSelector } from 'react-redux';
import { selectAuth } from '@features/auth/authSlice';

/** Convenience hook to read the auth slice. */
export const useAuth = () => useSelector(selectAuth);

export default useAuth;
