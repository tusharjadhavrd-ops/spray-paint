import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Simple countdown timer (in seconds). Used for the OTP "resend" cooldown.
 * Returns the remaining seconds, whether it's active, and a start() fn.
 */
export const useCountdown = (initialSeconds = 30) => {
  const [seconds, setSeconds] = useState(0);
  const intervalRef = useRef(null);

  const clear = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const start = useCallback(
    (from = initialSeconds) => {
      clear();
      setSeconds(from);
      intervalRef.current = setInterval(() => {
        setSeconds((prev) => {
          if (prev <= 1) {
            clear();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    },
    [initialSeconds, clear]
  );

  useEffect(() => clear, [clear]);

  return { seconds, isActive: seconds > 0, start };
};

export default useCountdown;
