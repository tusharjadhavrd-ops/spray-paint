/**
 * Download a file from a URL with an explicit filename.
 *
 * Fetches the URL into a Blob and triggers a download via a temporary anchor.
 * Going through a Blob (rather than just setting <a download>) lets us honor the
 * given filename even for cross-origin links, where the `download` attribute is
 * otherwise ignored. Works for blob: URLs and CORS-enabled http(s) links alike.
 *
 * @param {string} url       The file location (e.g. backend-provided link).
 * @param {string} fileName  Name to save the file as.
 */
export async function downloadFile(url, fileName = 'download') {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download file (${response.status})`);
  }

  const blob = await response.blob();
  const objectUrl = URL.createObjectURL(blob);

  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();

  URL.revokeObjectURL(objectUrl);
}

export default downloadFile;
