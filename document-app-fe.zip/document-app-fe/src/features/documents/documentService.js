/**
 * Document generation service.
 *
 * DEMO ONLY: `generateDocument` simulates a backend call — it waits, then builds
 * a small PDF locally and hands back an object URL plus a dummy filename. When
 * the real API is ready, replace the body of `generateDocument` with the fetch;
 * keep the returned shape ({ fileName, fileUrl }) and the UI needs no changes.
 */

const SIMULATED_DELAY_MS = 1500;

/**
 * Build a minimal, valid single-page PDF as a Blob. The text is sanitized to
 * ASCII so byte offsets used in the xref table stay correct.
 */
function buildDummyPdf(rawText) {
  const text =
    String(rawText)
      .replace(/[^\x20-\x7E]/g, ' ') // ASCII printable only -> 1 byte per char
      .slice(0, 200)
      .replace(/[\\()]/g, '\\$&') // escape PDF string specials
      .trim() || 'Generated document';

  const content = `BT /F1 24 Tf 72 720 Td (${text}) Tj ET`;
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] ' +
      '/Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    // Title shows in the PDF viewer's toolbar instead of the blob URL.
    '<< /Title (Generated document) /Producer (Document App) >>',
  ];

  const header = '%PDF-1.4\n';
  let bodyText = '';
  const offsets = [];
  objects.forEach((obj, i) => {
    offsets[i] = header.length + bodyText.length;
    bodyText += `${i + 1} 0 obj\n${obj}\nendobj\n`;
  });

  const xrefStart = header.length + bodyText.length;
  let xref = `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.forEach((offset) => {
    xref += `${String(offset).padStart(10, '0')} 00000 n \n`;
  });

  const trailer =
    `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info ${objects.length} 0 R >>\n` +
    `startxref\n${xrefStart}\n%%EOF`;

  return new Blob([header + bodyText + xref + trailer], { type: 'application/pdf' });
}

/**
 * Generate a document from a prompt.
 *
 * @param {string} prompt
 * @returns {Promise<{ fileName: string, fileUrl: string }>}
 */
export function generateDocument(prompt) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const blob = buildDummyPdf(prompt);
      resolve({
        // Backend will drive the real name; dummy placeholder for now.
        fileName: 'generated-document.pdf',
        fileUrl: URL.createObjectURL(blob),
      });
    }, SIMULATED_DELAY_MS);
  });
}

/**
 * Refine an already-generated document with extra instructions.
 *
 * DEMO ONLY: rebuilds a local PDF from the original prompt + the new orders.
 * Replace the body with the real API call (send `prompt` + `instructions`);
 * keep the returned shape ({ fileName, fileUrl }) and the UI needs no changes.
 *
 * @param {{ prompt?: string, instructions: string }} params
 * @returns {Promise<{ fileName: string, fileUrl: string }>}
 */
export function refineDocument({ prompt, instructions }) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const blob = buildDummyPdf(`${prompt || 'Generated document'} | Updated: ${instructions}`);
      resolve({
        fileName: 'generated-document.pdf',
        fileUrl: URL.createObjectURL(blob),
      });
    }, SIMULATED_DELAY_MS);
  });
}

const SAMPLE_DOCUMENTS = [
  { title: 'Project proposal', fileName: 'project-proposal.pdf', date: '2026-06-24' },
  { title: 'Invoice 1042', fileName: 'invoice-1042.pdf', date: '2026-06-18' },
  { title: 'Team meeting notes', fileName: 'meeting-notes.pdf', date: '2026-06-11' },
  { title: 'Q2 performance report', fileName: 'q2-report.pdf', date: '2026-05-30' },
  { title: 'NDA agreement', fileName: 'nda-agreement.pdf', date: '2026-05-21' },
];

/**
 * List previously generated documents.
 *
 * DEMO ONLY: returns sample rows backed by locally-built PDFs. Replace the body
 * with the real API call; keep the row shape so the table needs no changes:
 * { id, name, fileName, date, fileUrl }.
 *
 * @returns {Promise<Array<{ id: string, name: string, fileName: string, date: string, fileUrl: string }>>}
 */
export function listDocuments() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(
        SAMPLE_DOCUMENTS.map((doc, index) => ({
          id: `doc-${index + 1}`,
          name: doc.title,
          fileName: doc.fileName,
          date: doc.date,
          fileUrl: URL.createObjectURL(buildDummyPdf(doc.title)),
        })),
      );
    }, 700);
  });
}

export default generateDocument;
