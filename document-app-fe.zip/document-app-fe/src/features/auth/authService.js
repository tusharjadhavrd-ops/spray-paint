import { DEMO_USERS, DEMO_OTP } from '@constants';

/**
 * Simulated auth API. Everything resolves/rejects on a timer so the UI can
 * exercise real loading/error states. Swap these functions for real `fetch`/
 * axios calls when a backend is available — the slice & components won't change.
 */

const FAKE_LATENCY = 700;

const delay = (ms = FAKE_LATENCY) => new Promise((res) => setTimeout(res, ms));

const sanitizeUser = ({ password, ...rest }) => rest; // never expose password

/** Validate email + password against the demo user list. */
export const login = async ({ email, password }) => {
  await delay();
  const match = DEMO_USERS.find(
    (u) => u.email.toLowerCase() === String(email).toLowerCase().trim()
  );
  if (!match || match.password !== password) {
    throw new Error('Invalid email or password.');
  }
  return {
    user: sanitizeUser(match),
    token: `demo-token-${match.id}-${Date.now()}`,
  };
};

/** "Send" an OTP. In demo mode the OTP is always DEMO_OTP. */
export const sendOtp = async ({ email }) => {
  await delay(500);
  if (!email) throw new Error('Email is required to send an OTP.');
  // In a real app the backend emails/SMSes the code. Here we log it for demo.
  // eslint-disable-next-line no-console
  console.info(`[DEMO] OTP for ${email} is: ${DEMO_OTP}`);
  return { sent: true };
};

/** Verify the OTP code against the demo OTP. */
export const verifyOtp = async ({ otp }) => {
  await delay(500);
  if (otp !== DEMO_OTP) {
    throw new Error('Incorrect OTP. Please try again.');
  }
  return { verified: true };
};

/** Register a new user (demo: just echoes back a sanitized user). */
export const register = async ({ name, email }) => {
  await delay();
  const exists = DEMO_USERS.some(
    (u) => u.email.toLowerCase() === String(email).toLowerCase().trim()
  );
  if (exists) {
    throw new Error('An account with this email already exists.');
  }
  return {
    user: {
      id: `usr_${Date.now()}`,
      name: name || email.split('@')[0],
      email: email.trim(),
      role: 'user',
    },
    token: `demo-token-new-${Date.now()}`,
  };
};

/** Reset password (demo: no-op success). */
export const resetPassword = async ({ email }) => {
  await delay();
  if (!email) throw new Error('Email is required.');
  return { reset: true };
};

export default { login, sendOtp, verifyOtp, register, resetPassword };
