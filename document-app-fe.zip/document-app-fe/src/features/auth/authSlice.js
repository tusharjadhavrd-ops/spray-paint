import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { STORAGE_KEYS } from '@constants';
import * as authService from './authService';

/* ----------------------------- persistence ------------------------------- */

const loadAuth = () => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AUTH);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

const persistAuth = (auth) => {
  try {
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(auth));
  } catch {
    /* ignore quota / privacy-mode errors */
  }
};

const clearAuth = () => localStorage.removeItem(STORAGE_KEYS.AUTH);

/* ------------------------------- thunks ---------------------------------- */

export const loginUser = createAsyncThunk(
  'auth/login',
  async (credentials, { rejectWithValue }) => {
    try {
      return await authService.login(credentials);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const registerUser = createAsyncThunk(
  'auth/register',
  async (payload, { rejectWithValue }) => {
    try {
      return await authService.register(payload);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

/* -------------------------------- slice ---------------------------------- */

const persisted = loadAuth();

const initialState = {
  user: persisted?.user ?? null,
  token: persisted?.token ?? null,
  isAuthenticated: Boolean(persisted?.token),
  status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
  error: null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout(state) {
      state.user = null;
      state.token = null;
      state.isAuthenticated = false;
      state.status = 'idle';
      state.error = null;
      clearAuth();
    },
    clearError(state) {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    const onPending = (state) => {
      state.status = 'loading';
      state.error = null;
    };
    const onAuthSuccess = (state, { payload }) => {
      state.status = 'succeeded';
      state.user = payload.user;
      state.token = payload.token;
      state.isAuthenticated = true;
      persistAuth({ user: payload.user, token: payload.token });
    };
    const onRejected = (state, { payload, error }) => {
      state.status = 'failed';
      state.error = payload || error?.message || 'Something went wrong.';
    };

    builder
      .addCase(loginUser.pending, onPending)
      .addCase(loginUser.fulfilled, onAuthSuccess)
      .addCase(loginUser.rejected, onRejected)
      .addCase(registerUser.pending, onPending)
      .addCase(registerUser.fulfilled, onAuthSuccess)
      .addCase(registerUser.rejected, onRejected);
  },
});

export const { logout, clearError } = authSlice.actions;

/* ------------------------------ selectors -------------------------------- */

export const selectAuth = (state) => state.auth;
export const selectUser = (state) => state.auth.user;
export const selectIsAuthenticated = (state) => state.auth.isAuthenticated;
export const selectAuthStatus = (state) => state.auth.status;
export const selectAuthError = (state) => state.auth.error;

export default authSlice.reducer;
