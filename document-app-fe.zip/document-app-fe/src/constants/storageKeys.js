/** localStorage keys — namespaced to avoid collisions. */
export const STORAGE_KEYS = {
  AUTH: 'docapp.auth',
  THEME_MODE: 'docapp.themeMode',
  PROFILE: 'docapp.profile',
};

export default STORAGE_KEYS;
