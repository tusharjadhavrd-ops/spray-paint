/** Centralized route paths so links never drift from the router config. */
export const ROUTES = {
  LOGIN: '/login',
  REGISTER: '/register',
  RESET_PASSWORD: '/reset-password',
  CREATE_DOCUMENT: '/documents/new',
  DOCUMENTS: '/documents',
  PROFILE: '/profile',
  TERMS: '/terms',
  ROOT: '/',
};

export default ROUTES;
