/**
 * Demo credentials & OTP — FRONTEND ONLY.
 *
 * These are stand-ins until a real backend/auth API is wired up.
 * Login is validated against DEMO_USERS; OTP flows validate against DEMO_OTP.
 *
 * ⚠️  Do NOT use this pattern for real authentication. Never ship real secrets
 *     in client-side constants.
 */

export const DEMO_USERS = [
  {
    id: 'usr_001',
    name: 'Demo Admin',
    email: 'admin@demo.com',
    password: 'Admin@123',
    role: 'admin',
  },
  {
    id: 'usr_002',
    name: 'Demo User',
    email: 'user@demo.com',
    password: 'User@123',
    role: 'user',
  },
];

/** Static OTP accepted by the register & reset-password flows during demo. */
export const DEMO_OTP = '123456';

/** Length of the OTP code (used by the OtpInput component). */
export const OTP_LENGTH = 6;

/** Seconds before the user can request a new OTP. */
export const OTP_RESEND_SECONDS = 30;
