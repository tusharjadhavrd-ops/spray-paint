/** Shared validation rules & regexes used across the auth forms. */

export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// At least 8 chars, one uppercase, one lowercase, one number, one special char.
export const PASSWORD_REGEX =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;

export const PASSWORD_RULE_HINT =
  'Min 8 characters with uppercase, lowercase, number & special character.';

export const isValidEmail = (email) => EMAIL_REGEX.test(String(email).trim());

export const isValidPassword = (password) => PASSWORD_REGEX.test(password);
