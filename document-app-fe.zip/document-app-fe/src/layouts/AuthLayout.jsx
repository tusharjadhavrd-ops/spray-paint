import { Box, Paper, Stack, Typography, useTheme } from '@mui/material';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import ThemeToggle from '@components/common/ThemeToggle';

/**
 * Two-panel monochrome auth shell.
 * Left: branding panel (inverted colors). Right: the form card.
 * Collapses to a single column on small screens.
 */
const AuthLayout = ({ title, subtitle, children, footer }) => {
  const theme = useTheme();
  const inverted =
    theme.palette.mode === 'light' ? '#000000' : '#ffffff';
  const invertedText =
    theme.palette.mode === 'light' ? '#ffffff' : '#000000';

  return (
    <Box
      sx={{
        minHeight: '100%',
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
        bgcolor: 'background.default',
      }}
    >
      {/* Branding panel */}
      <Box
        sx={{
          display: { xs: 'none', md: 'flex' },
          flexDirection: 'column',
          justifyContent: 'space-between',
          p: 6,
          bgcolor: inverted,
          color: invertedText,
        }}
      >
        <Stack direction="row" spacing={1.5} alignItems="center">
          <DescriptionOutlinedIcon sx={{ fontSize: 32 }} />
          <Typography variant="h6" fontWeight={700} letterSpacing="0.04em">
            DOCUMENT&nbsp;APP
          </Typography>
        </Stack>

        <Box>
          <Typography variant="h3" fontWeight={800} sx={{ mb: 2 }}>
            Manage your documents with clarity.
          </Typography>
          <Typography variant="body1" sx={{ opacity: 0.75, maxWidth: 420 }}>
            A focused, black-and-white workspace for storing, sharing and
            organizing everything that matters.
          </Typography>
        </Box>

        <Typography variant="caption" sx={{ opacity: 0.6 }}>
          © {new Date().getFullYear()} Document App. All rights reserved.
        </Typography>
      </Box>

      {/* Form panel */}
      <Box
        sx={{
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          p: { xs: 3, sm: 6 },
        }}
      >
        <Box sx={{ position: 'absolute', top: 16, right: 16 }}>
          <ThemeToggle />
        </Box>

        <Paper
          variant="outlined"
          sx={{
            width: '100%',
            maxWidth: 440,
            p: { xs: 3, sm: 5 },
            borderColor: 'divider',
          }}
        >
          {/* Mobile-only brand */}
          <Stack
            direction="row"
            spacing={1.5}
            alignItems="center"
            sx={{ display: { xs: 'flex', md: 'none' }, mb: 3 }}
          >
            <DescriptionOutlinedIcon sx={{ fontSize: 28 }} />
            <Typography variant="h6" fontWeight={700}>
              DOCUMENT APP
            </Typography>
          </Stack>

          <Typography variant="h4" fontWeight={800} gutterBottom>
            {title}
          </Typography>
          {subtitle && (
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              {subtitle}
            </Typography>
          )}

          {children}

          {footer && <Box sx={{ mt: 3 }}>{footer}</Box>}
        </Paper>
      </Box>
    </Box>
  );
};

export default AuthLayout;
