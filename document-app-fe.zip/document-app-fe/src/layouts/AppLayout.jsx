import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  AppBar,
  Toolbar,
  Typography,
  Box,
  Container,
  IconButton,
  Avatar,
  Menu,
  MenuItem,
  Divider,
  ListItemIcon,
  Stack,
  Button,
} from '@mui/material';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import NoteAddOutlinedIcon from '@mui/icons-material/NoteAddOutlined';
import HistoryOutlinedIcon from '@mui/icons-material/HistoryOutlined';
import PersonOutlineIcon from '@mui/icons-material/PersonOutlined';
import LogoutIcon from '@mui/icons-material/Logout';
import { logout, selectUser } from '@features/auth/authSlice';
import { ROUTES } from '@constants';
import ThemeToggle from '@components/common/ThemeToggle';
import Footer from '@components/common/Footer';

/** Primary navigation shown in the top AppBar. */
const NAV_ITEMS = [
  { label: 'Create document', to: ROUTES.CREATE_DOCUMENT, icon: <NoteAddOutlinedIcon /> },
  { label: 'View previous', to: ROUTES.DOCUMENTS, icon: <HistoryOutlinedIcon /> },
  { label: 'Profile', to: ROUTES.PROFILE, icon: <PersonOutlineIcon /> },
];

/** Shell for authenticated pages: top AppBar + content container. */
const AppLayout = ({ children }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const user = useSelector(selectUser);
  const [anchorEl, setAnchorEl] = useState(null);

  // Pick the single best match so nested paths (e.g. /documents/new) don't also
  // light up their parent (/documents) — longest matching `to` wins.
  const activeNav = NAV_ITEMS.filter(
    (item) => pathname === item.to || pathname.startsWith(`${item.to}/`),
  ).reduce((best, item) => (!best || item.to.length > best.to.length ? item : best), null);

  const isActive = (to) => activeNav?.to === to;

  const goTo = (to) => {
    setAnchorEl(null);
    navigate(to);
  };

  const handleLogout = () => {
    setAnchorEl(null);
    dispatch(logout());
    navigate(ROUTES.LOGIN, { replace: true });
  };

  const initials = (user?.name || user?.email || '?')
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <Box
      sx={{
        minHeight: '100%',
        display: 'flex',
        flexDirection: 'column',
        bgcolor: 'background.default',
      }}
    >
      <AppBar
        position="sticky"
        sx={{ borderBottom: '1px solid', borderColor: 'divider' }}
      >
        <Toolbar sx={{ gap: 1 }}>
          <Stack
            direction="row"
            alignItems="center"
            onClick={() => navigate(ROUTES.CREATE_DOCUMENT)}
            sx={{ cursor: 'pointer', userSelect: 'none' }}
          >
            <DescriptionOutlinedIcon />
          </Stack>

          <Stack direction="row" spacing={0.5} alignItems="center" sx={{ ml: { xs: 1, md: 3 } }}>
            {NAV_ITEMS.map((item) => (
              <Button
                key={item.to}
                onClick={() => goTo(item.to)}
                startIcon={item.icon}
                color="inherit"
                sx={{
                  px: { xs: 1, sm: 1.5 },
                  minWidth: 'auto',
                  borderRadius: 0,
                  fontWeight: isActive(item.to) ? 700 : 500,
                  borderBottom: '2px solid',
                  borderColor: isActive(item.to) ? 'currentColor' : 'transparent',
                  '& .MuiButton-startIcon': { mr: { xs: 0, sm: 0.75 } },
                }}
              >
                <Box component="span" sx={{ display: { xs: 'none', sm: 'inline' } }}>
                  {item.label}
                </Box>
              </Button>
            ))}
          </Stack>

          <Box sx={{ flexGrow: 1 }} />

          <ThemeToggle />

          <IconButton onClick={(e) => setAnchorEl(e.currentTarget)} sx={{ ml: 1 }}>
            <Avatar
              sx={{
                width: 36,
                height: 36,
                bgcolor: 'primary.main',
                color: 'primary.contrastText',
                fontSize: 14,
                fontWeight: 700,
              }}
            >
              {initials}
            </Avatar>
          </IconButton>

          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={() => setAnchorEl(null)}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          >
            <Box sx={{ px: 2, py: 1 }}>
              <Typography variant="subtitle2">{user?.name}</Typography>
              <Typography variant="caption" color="text.secondary">
                {user?.email}
              </Typography>
            </Box>
            <Divider />
            <MenuItem onClick={handleLogout}>
              <ListItemIcon>
                <LogoutIcon fontSize="small" />
              </ListItemIcon>
              Log out
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      <Container component="main" maxWidth="lg" sx={{ py: 4, flexGrow: 1 }}>
        {children}
      </Container>

      <Footer />
    </Box>
  );
};

export default AppLayout;
