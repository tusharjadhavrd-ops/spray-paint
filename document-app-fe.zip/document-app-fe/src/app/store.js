import { configureStore } from '@reduxjs/toolkit';
import authReducer from '@features/auth/authSlice';

/**
 * Central Redux store. Add feature reducers here as the app grows
 * (documents, users, settings, ...).
 */
export const store = configureStore({
  reducer: {
    auth: authReducer,
  },
  devTools: import.meta.env.MODE !== 'production',
});

export default store;
