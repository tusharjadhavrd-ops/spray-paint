# Document App — Frontend

Large-scale React + Vite application with a **black & white** Material UI theme,
Redux Toolkit state, Context API theming, and complete auth flows (login,
register with OTP + captcha, reset password with OTP).

## Tech stack

| Concern        | Choice                                  |
| -------------- | --------------------------------------- |
| Runtime        | Node 22 (pinned via Volta)              |
| Build tool     | Vite 8                                   |
| UI / framework  | React 19 + MUI 9 (`@mui/material`)      |
| Theming        | MUI ThemeProvider + Context API toggle  |
| State          | Redux Toolkit 2 + React-Redux 9         |
| Routing        | React Router 7 (lazy-loaded, guarded)   |
| Linting        | ESLint 9 (flat config)                  |

> Bootstrap was intentionally left out — mixing its global CSS with MUI fights
> the monochrome theme. Add `react-bootstrap` later if a specific need arises.

## Getting started

```bash
npm install
npm run dev      # http://localhost:3000
```

Other scripts: `npm run build`, `npm run preview`, `npm run lint`.

## Demo credentials

Defined in [`src/constants/credentials.js`](src/constants/credentials.js):

| Role  | Email            | Password    |
| ----- | ---------------- | ----------- |
| admin | `admin@demo.com` | `Admin@123` |
| user  | `user@demo.com`  | `User@123`  |

**Demo OTP:** `123456` (also logged to the browser console when "sent").

## Auth flows

- **Login** — email + password validated against `DEMO_USERS`; on success the
  session is stored in Redux + `localStorage` and routes to `/home`.
- **Register** — name, email, password, captcha, Terms & Conditions, then a
  2-step OTP verification before the account is created.
- **Reset password** — email → OTP verification → set new password.

## Project structure

```
src/
  app/            # Redux store
  components/      # Reusable UI (Captcha, OtpInput, PasswordField, ThemeToggle)
  constants/       # Demo creds, routes, storage keys, validation rules
  features/        # Feature slices (auth: slice + service)
  hooks/           # useAuth, useCountdown
  layouts/         # AuthLayout (split screen), AppLayout (app shell)
  pages/           # auth/, home/, NotFound
  routes/          # AppRoutes + Protected/PublicOnly guards
  theme/           # MUI black & white theme + ColorModeContext
```

## Replacing the mock backend

All fake API calls live in
[`src/features/auth/authService.js`](src/features/auth/authService.js). Swap the
function bodies for real `fetch`/axios calls — the Redux slice and components
don't need to change.
