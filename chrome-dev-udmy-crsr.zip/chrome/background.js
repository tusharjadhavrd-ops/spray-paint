/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/config/environment.js":
/*!***********************************!*\
  !*** ./src/config/environment.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const environment = {
    apiHost: 'https://docs.jiocloudpc.com/resources/dev/pluginconfigs.json', // Development API host
    xApiKey: 'eRjp5UKQxN84jYl4NHsCrav1OBI24a7P',
    isProduction: false
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (environment); 

/***/ }),

/***/ "./src/core/config.js":
/*!****************************!*\
  !*** ./src/core/config.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @env */ "./src/config/environment.js");
/* harmony import */ var _storage_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.js */ "./src/core/storage.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./logger.js */ "./src/core/logger.js");
/**
 * Config module for fetching plugin configuration
 */





const logger = (0,_logger_js__WEBPACK_IMPORTED_MODULE_2__["default"])('CONFIG');

// ---------------------------------------------------------------------------
// TEMPORARY local site entries.
// Merged into whatever the remote plugin config returns so these sites work before
// the server-side config is updated.
// TODO: remove this block once docs.jiocloudpc.com/.../pluginconfigs.json lists
// these sites.
// NOTE: package_name is a placeholder (generic web app) — set the real native
// target here or in the remote config once decided.
// NOTE: Udemy streams via HLS, so its <video> src is a blob: URL. The background
// captures the HLS master playlist and swaps in the best-quality variant before
// launching native — see core/manifestCapture.js + messageRouter.handleLaunchVideoUrl.
// ---------------------------------------------------------------------------
const LOCAL_HOST_PERMISSIONS = [
  {
    name: 'Coursera',
    url: 'https://www.coursera.org/learn/',
    package_name: 'com.jio.web',
    is_pip: true,
    width: 100,
    height: 50,
    handler: 'default'
  },
  {
    name: 'Udemy',
    url: 'https://www.udemy.com/course/',
    package_name: 'com.jio.web',
    is_pip: true,
    width: 100,
    height: 50,
    handler: 'default',
    // Blob-based HLS: only show the play overlay once the background has captured a
    // playable .m3u8 for the tab (see contentScript.isRedirectable / manifestCapture).
    requiresStreamCapture: true
  }
];

/**
 * Merge the temporary local entries into a host-permissions list, skipping any
 * whose url the remote config already provides (dedupe by url). Idempotent.
 * @param {Array} remoteList
 * @returns {Array}
 */
function withLocalPermissions(remoteList) {
  const list = Array.isArray(remoteList) ? [...remoteList] : [];
  const existingUrls = new Set(list.map((site) => site && site.url));
  for (const local of LOCAL_HOST_PERMISSIONS) {
    if (!existingUrls.has(local.url)) {
      list.push(local);
    }
  }
  return list;
}

/**
 * Config class for managing plugin configuration
 */
class Config {
  constructor() {
    this.hostPermissions = [];
    this.config = null;
  }

  /**
   * Fetch plugin configuration from API
   * @returns {Promise<object>} Plugin configuration
   */
  async fetchPluginConfig() {
    try {
      
      const response = await fetch(_env__WEBPACK_IMPORTED_MODULE_0__["default"].apiHost, {
        method: 'GET',
        headers: {
          'accept': 'application/json',
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          // 'x-api-key': environment.xApiKey
        }
      });

      const pluginConfig = await response.json();

      this.config = pluginConfig;
      this.hostPermissions = withLocalPermissions(pluginConfig.configs?.host_permissions || []);

      // Persist so content scripts can reuse it across service-worker restarts
      // without another network call.
      await _storage_js__WEBPACK_IMPORTED_MODULE_1__.storage.setHostPermissions(this.hostPermissions);

      logger.info(`[CONFIG] Config fetched successfully, host permissions count: ${this.hostPermissions.length}`);
      return pluginConfig;
    } catch (error) {
      logger.error(`[CONFIG] Error fetching plugin config: ${error.message || error}`);
      // Even if the remote fetch fails, keep the temporary local sites available.
      this.hostPermissions = withLocalPermissions([]);
      return {};
    }
  }

  /**
   * Ensure host permissions are available, using the cheapest source first:
   *   1. in-memory cache (this service-worker lifetime)
   *   2. persisted storage (from a previous launch)
   *   3. network fetch (last resort)
   * @returns {Promise<Array>} Host permissions
   */
  async ensureLoaded() {
    if (this.hasHostPermissions()) {
      return this.hostPermissions;
    }

    try {
      const stored = await _storage_js__WEBPACK_IMPORTED_MODULE_1__.storage.getHostPermissions();
      if (stored && stored.length > 0) {
        // Merge locals in case the stored list predates them.
        this.hostPermissions = withLocalPermissions(stored);
        logger.info(`[CONFIG] Loaded ${stored.length} host permissions from storage`);
        return this.hostPermissions;
      }
    } catch (e) {
      logger.error(`[CONFIG] Error loading stored host permissions: ${e.message || e}`);
    }

    await this.fetchPluginConfig();
    return this.hostPermissions;
  }

  /**
   * Get host permissions
   * @returns {string[]} Array of host permissions
   */
  getHostPermissions() {
    return this.hostPermissions;
  }

  /**
   * Check if host permissions are loaded
   * @returns {boolean}
   */
  hasHostPermissions() {
    return this.hostPermissions.length > 0;
  }
}

// Export singleton instance
const config = new Config();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (config);



/***/ }),

/***/ "./src/core/logger.js":
/*!****************************!*\
  !*** ./src/core/logger.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createLogger: () => (/* binding */ createLogger),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @env */ "./src/config/environment.js");


const browserAPI = typeof browser !== 'undefined' ? browser : (typeof chrome !== 'undefined' ? chrome : null);

class Logger {
  constructor(moduleName = 'APP') {
    this.appName = 'media redirection plugin';
    this.moduleName = moduleName;
    this.logServerUrl = 'http://localhost:9900/log';
    
    this.batchSize = 10;
    this.batchTimeout = 3000;
    this.logQueue = [];
    this.batchTimer = null;
    this.isBackground = typeof window === 'undefined' || typeof document === 'undefined';
    
    this.setupUnloadHandler();
  }

  getBrowser() {
    if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.getBrowserInfo) {
      return 'firefox';
    }
    if (typeof chrome !== 'undefined') {
      return 'chrome';
    }
    return 'unknown';
  }

  getEnvironment() {
    try {
      return _env__WEBPACK_IMPORTED_MODULE_0__["default"].isProduction ? 'production' : 'development';
    } catch (err) {
      return 'unknown';
    }
  }

  getFormattedDateTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
  }

  formatLog(level, logString) {
    const dateTime = this.getFormattedDateTime();
    const browser = this.getBrowser();
    const env = this.getEnvironment();
    
    return `[${dateTime}] [${level}] [${this.appName}] [${env}] [${logString}] [${browser}]`;
  }

  setupUnloadHandler() {
    if (typeof window !== 'undefined') {
      window.addEventListener('beforeunload', () => {
        this.flushBatch();
      });
      
      if (typeof document !== 'undefined') {
        document.addEventListener('visibilitychange', () => {
          if (document.hidden) {
            this.flushBatch();
          }
        });
      }
    }
    
    if (browserAPI && browserAPI.runtime && browserAPI.runtime.onSuspend) {
      browserAPI.runtime.onSuspend.addListener(() => {
        this.flushBatch();
      });
    }
  }

  addToBatch(logString) {
    this.logQueue.push(logString);
    
    if (this.logQueue.length >= this.batchSize) {
      this.flushBatch();
      return;
    }
    
    if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.flushBatch();
      }, this.batchTimeout);
    }
  }

  flushBatch() {
    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = null;
    }
    
    if (this.logQueue.length === 0) {
      return;
    }
    
    const batch = this.logQueue.slice();
    this.logQueue = [];
    
    this.sendBatchToServer(batch);
  }

  sendBatchToServer(logBatch) {
    if (this.isBackground) {
      this.fetchToLogServer(logBatch);
    } else {
      this.forwardToBackground(logBatch);
    }
  }

  fetchToLogServer(logBatch) {
    try {
      const batchBody = logBatch.join('\n');
      fetch(this.logServerUrl, {
        method: 'POST',
        body: batchBody,
        headers: { 'Content-Type': 'text/plain' }
      }).catch(() => {});
    } catch (err) {}
  }

  forwardToBackground(logBatch) {
    try {
      if (browserAPI && browserAPI.runtime && browserAPI.runtime.sendMessage) {
        browserAPI.runtime.sendMessage(
          { action: 'LOG_BATCH', logs: logBatch }
        ).catch(() => {});
      }
    } catch (err) {}
  }

  sendToServer(logString) {
    this.addToBatch(logString);
  }

  info(logString) {
    const formattedLog = this.formatLog('INFO', logString);
    this.sendToServer(formattedLog);
  }

  error(logString) {
    const formattedLog = this.formatLog('ERROR', logString);
    this.sendToServer(formattedLog);
  }

  warn(logString) {
    const formattedLog = this.formatLog('WARN', logString);
    this.sendToServer(formattedLog);
  }

  debug(logString) {
    const formattedLog = this.formatLog('DEBUG', logString);
    this.sendToServer(formattedLog);
  }
}

function createLogger(appName) {
  return new Logger(appName);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (createLogger);


/***/ }),

/***/ "./src/core/manifestCapture.js":
/*!*************************************!*\
  !*** ./src/core/manifestCapture.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   manifestCapture: () => (/* binding */ manifestCapture)
/* harmony export */ });
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./logger.js */ "./src/core/logger.js");
/**
 * Manifest capture — Udemy (HLS).
 *
 * We do NOT look at the page's <video> element at all (its src is an unusable blob:).
 * Instead we target the HLS playlist network calls directly: Udemy fetches `.m3u8`
 * playlists over the network, and one of those URLs, pasted straight into a browser,
 * plays the whole lecture. We observe those requests here and remember the best one per
 * tab, then hand it to native on launch (see messageRouter.handleLaunchVideoUrl).
 *
 * Udemy HLS URLs look like:
 *   variant: .../files/<videoKey>/<n>/hls/AVC_<w>x<h>_<bitrate>.../<hash>.m3u8?token=...
 *   master:  .../files/<videoKey>/<n>/<hash>.m3u8?token=...            (no /hls/, no res)
 * The `<videoKey>` (a per-lecture hash) lets us tell one video from another.
 *
 * Selection rule per tab:
 *   - New video (videoKey changes on refresh / lecture switch) → reset to it.
 *   - Same video → keep the highest resolution (parsed from AVC_<w>x<h> in the URL).
 * A variant (has a resolution) always outranks the master (resolution score 0), so the
 * master is only used as a fallback when no variant was seen.
 *
 * Lifetime note (MV3): the in-memory map is lost if the service worker is evicted, so we
 * also mirror into storage.session (in-memory, cleared on browser restart).
 */



const logger = (0,_logger_js__WEBPACK_IMPORTED_MODULE_0__["default"])('MANIFEST_CAPTURE');

// Browser API compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

const SESSION_PREFIX = 'manifest:';

/**
 * Parse a Udemy HLS playlist URL into { videoKey, score, url }, or null if it isn't one.
 * score = width*height for a variant, 0 for the master (used only as a fallback).
 * @param {string} url
 */
function parseUdemyManifest(url) {
  if (!/udemy/i.test(url) || !/\.m3u8(\?|$)/i.test(url)) {
    return null;
  }
  const keyMatch = url.match(/\/files\/([^/]+)\//i);
  const resMatch = url.match(/\/hls\/[A-Za-z0-9]+_(\d+)x(\d+)_/i);
  return {
    videoKey: keyMatch ? keyMatch[1] : 'unknown',
    score: resMatch ? parseInt(resMatch[1], 10) * parseInt(resMatch[2], 10) : 0,
    url
  };
}

function hasSessionStorage() {
  return !!(browserAPI.storage && browserAPI.storage.session);
}

class ManifestCapture {
  constructor() {
    this.byTab = new Map(); // tabId -> { videoKey, score, url }
    this.initialized = false;
  }

  /**
   * Register the webRequest observer. Must be called synchronously at top level so the
   * service worker wakes for these events.
   */
  initialize() {
    if (this.initialized) {
      return;
    }
    if (!browserAPI.webRequest || !browserAPI.webRequest.onBeforeRequest) {
      logger.warn('[MANIFEST_CAPTURE] webRequest API unavailable; Udemy HLS capture disabled');
      return;
    }

    // Observation only (no blocking). Scoped to Udemy hosts.
    browserAPI.webRequest.onBeforeRequest.addListener(
      (details) => this.onRequest(details),
      { urls: ['*://*.udemy.com/*', '*://*.udemycdn.com/*'] }
    );

    if (browserAPI.tabs && browserAPI.tabs.onRemoved) {
      browserAPI.tabs.onRemoved.addListener((tabId) => this.clearTab(tabId));
    }

    this.initialized = true;
    logger.info('[MANIFEST_CAPTURE] Initialized (watching Udemy HLS playlists)');
  }

  onRequest(details) {
    const tabId = details.tabId;
    if (tabId == null || tabId < 0) {
      return;
    }

    // Refresh / full navigation → forget the previous video's manifest.
    if (details.type === 'main_frame') {
      this.clearTab(tabId);
      return;
    }

    const info = parseUdemyManifest(details.url);
    if (!info) {
      return;
    }

    const current = this.byTab.get(tabId);
    if (!current || current.videoKey !== info.videoKey) {
      // First manifest, or a different video (lecture switch) → newest video wins.
      this.byTab.set(tabId, info);
      this.persist(tabId, info);
      logger.info(`[MANIFEST_CAPTURE] Captured manifest for tab ${tabId} (score ${info.score})`);
    } else if (info.score > current.score) {
      // Same video, higher resolution → upgrade.
      this.byTab.set(tabId, info);
      this.persist(tabId, info);
      logger.info(`[MANIFEST_CAPTURE] Upgraded manifest for tab ${tabId} (score ${info.score})`);
    }
  }

  /**
   * Best captured manifest URL for a tab (highest resolution of the current video).
   * @param {number} tabId
   * @returns {Promise<string|null>}
   */
  async getManifestForTab(tabId) {
    const entry = this.byTab.get(tabId);
    if (entry) {
      return entry.url;
    }
    if (hasSessionStorage()) {
      try {
        const key = SESSION_PREFIX + tabId;
        const result = await browserAPI.storage.session.get(key);
        const stored = result && result[key];
        return stored ? stored.url : null;
      } catch (e) {
        logger.error(`[MANIFEST_CAPTURE] Error reading session storage: ${e.message || e}`);
      }
    }
    return null;
  }

  persist(tabId, entry) {
    if (!hasSessionStorage()) {
      return;
    }
    try {
      Promise.resolve(browserAPI.storage.session.set({ [SESSION_PREFIX + tabId]: entry })).catch(() => {});
    } catch (e) {
      logger.error(`[MANIFEST_CAPTURE] Error writing session storage: ${e.message || e}`);
    }
  }

  clearTab(tabId) {
    this.byTab.delete(tabId);
    if (hasSessionStorage()) {
      try {
        Promise.resolve(browserAPI.storage.session.remove(SESSION_PREFIX + tabId)).catch(() => {});
      } catch (e) {
        // best effort
      }
    }
  }
}

// Export singleton instance
const manifestCapture = new ManifestCapture();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (manifestCapture);


/***/ }),

/***/ "./src/core/messageRouter.js":
/*!***********************************!*\
  !*** ./src/core/messageRouter.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   messageRouter: () => (/* binding */ messageRouter)
/* harmony export */ });
/* harmony import */ var _nativePort_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nativePort.js */ "./src/core/nativePort.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config.js */ "./src/core/config.js");
/* harmony import */ var _storage_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./storage.js */ "./src/core/storage.js");
/* harmony import */ var _manifestCapture_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./manifestCapture.js */ "./src/core/manifestCapture.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils.js */ "./src/core/utils.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./logger.js */ "./src/core/logger.js");
/**
 * Message Router module for routing commands
 * Handles all message routing from content scripts and other sources
 */








const logger = (0,_logger_js__WEBPACK_IMPORTED_MODULE_5__["default"])('MSG_ROUTER');

// Browser API compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

/**
 * MessageRouter class for handling message routing
 */
class MessageRouter {
  constructor() {
    this.currentVideoId = '';
    this.currentVideoMetadata = null;
    this.currentVideoTabId = '';
  }

  /**
   * Initialize message router
   * 
   * This sets up all the listeners needed for the extension to work:
   * 1. Message listener - receives messages from content scripts
   * 2. Tab event listeners - handles tab close/switch events
   * 
   * This is called once during extension startup.
   */
  initialize() {
    // Set up message listener
    // This receives messages from content scripts running on web pages
    // When a content script sends a message, handleMessage() is called
    browserAPI.runtime.onMessage.addListener((request, sender, sendResponse) => {
      return this.handleMessage(request, sender, sendResponse);
    });

    // Set up tab listeners
    // These handle events like tab closing or tab switching
    // Used to pause/resume videos when user switches tabs
    this.setupTabListeners();
  }

  /**
   * Handle incoming messages from content scripts
   * 
   * This is the main routing function. It receives messages from content scripts
   * and routes them to the appropriate handler based on the action type.
   * 
   * Supported Actions:
   * - FETCH_PLUGIN_CONFIG: Get host permissions from config
   * - CHECK_NATIVE_PORT_STATUS: Check if native port is connected
   * - RECONNECT_NATIVE_PORT: Manually trigger reconnection
   * - LAUNCH_VIDEO_URL: Launch video in native app
   * 
   * @param {object} request - Request object with 'action' and other data
   * @param {object} sender - Information about who sent the message (tab, etc.)
   * @param {Function} sendResponse - Callback to send response back
   * @returns {boolean} True if async response (keeps channel open), false if sync
   */
  handleMessage(request, sender, sendResponse) {
    // Route message to appropriate handler based on action type
    switch (request.action) {
      case "FETCH_PLUGIN_CONFIG":
        // Content script wants to know which websites are allowed
        return this.handleFetchPluginConfig(sendResponse);
      
      case "CHECK_NATIVE_PORT_STATUS":
        // Content script wants to check if native app is connected (read-only)
        return this.handleCheckNativePortStatus(sendResponse);

      case "CONNECT_NATIVE_PORT":
        // Content script is on a configured site and wants an on-demand connection.
        // This is the ONLY message that may spawn/connect the native app.
        return this.handleConnectNativePort(sendResponse);

      case "RECONNECT_NATIVE_PORT":
        // User manually requested reconnection (e.g., from UI button)
        return this.handleReconnectNativePort(sendResponse);

      case "LOG_BATCH":
        // Content script forwards log lines; background POSTs to localhost (avoids PNA popup on pages)
        return this.handleLogBatch(request, sendResponse);
      
      case "LAUNCH_VIDEO_URL":
        // User clicked video button - launch in native app
        return this.handleLaunchVideoUrl(request, sender, sendResponse);
      
      default:
        // Unknown action - log error and return error response
        logger.error(`[MSG_ROUTER] Unknown action: ${request.action}`);
        sendResponse({ error: 'Unknown action' });
        return false; // Sync response (channel closes immediately)
    }
  }

  /**
   * Handle FETCH_PLUGIN_CONFIG action
   * 
   * Content scripts call this to get the list of allowed websites (host permissions).
   * The config is cached, so we only fetch from API once.
   * 
   * Flow:
   * 1. Check if permissions are already cached
   * 2. If not cached: Fetch from API, cache, then return
   * 3. If cached: Return cached permissions immediately
   * 
   * @param {Function} sendResponse - Callback to send response
   * @returns {boolean} True (async response)
   */
  handleFetchPluginConfig(sendResponse) {
    // Resolve host permissions from the cheapest available source:
    // memory cache → persisted storage → network fetch (see config.ensureLoaded).
    _config_js__WEBPACK_IMPORTED_MODULE_1__.config.ensureLoaded().then(hostPermissions => {
      logger.info(`[MSG_ROUTER] Plugin config sent to content script (${(hostPermissions || []).length} sites)`);
      sendResponse({ host_permissions: hostPermissions || [] });
    }).catch(error => {
      logger.error(`[MSG_ROUTER] Failed to resolve plugin config: ${error.message || error}`);
      sendResponse({ error: error.message });
    });
    return true; // Async response (keeps channel open)
  }

  /**
   * Handle CHECK_NATIVE_PORT_STATUS action
   *
   * Read-only status check. Content scripts call this to see if the native app is
   * currently connected. This must NOT trigger a connection/reconnection — that would
   * spawn the native process on every page. Connecting is done explicitly via
   * CONNECT_NATIVE_PORT, and only when the page matches a configured site.
   *
   * @param {Function} sendResponse - Callback to send response
   * @returns {boolean} True (async response)
   */
  handleCheckNativePortStatus(sendResponse) {
    _storage_js__WEBPACK_IMPORTED_MODULE_2__.storage.isNativePortConnected().then(isConnected => {
      if (isConnected) {
        logger.debug('[MSG_ROUTER] Native port status check: true');
      } else {
        logger.debug('[MSG_ROUTER] Native port status check: false');
      }
      sendResponse({ isConnected: isConnected });
    }).catch((error) => {
      // Error checking status - assume disconnected
      logger.error(`[MSG_ROUTER] Error checking native port status: ${error.message || error}`);
      sendResponse({ isConnected: false });
    });
    return true; // Async response (keeps channel open for storage check)
  }

  /**
   * Handle CONNECT_NATIVE_PORT action
   *
   * Establishes the native connection ON DEMAND. This is the only path that may
   * spawn the native app, and the content script only sends it when the current URL
   * matches a configured site. A single connection attempt is made (no background
   * reconnection loop), so on devices without the native app this fails fast and
   * simply reports isConnected:false — the content script then shows no overlay.
   *
   * @param {Function} sendResponse - Callback to send response
   * @returns {boolean} True (async response)
   */
  handleConnectNativePort(sendResponse) {
    (async () => {
      try {
        // Already connected in this service-worker lifetime — nothing to spawn.
        if (_nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.isConnected()) {
          await _storage_js__WEBPACK_IMPORTED_MODULE_2__.storage.updateNativePortStatus(true);
          sendResponse({ isConnected: true });
          return;
        }

        const port = await _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.initialize();
        const connected = !!(port && _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.isConnected());
        await _storage_js__WEBPACK_IMPORTED_MODULE_2__.storage.updateNativePortStatus(connected);

        if (connected) {
          logger.info('[MSG_ROUTER] Native port connected on demand');
        } else {
          logger.debug('[MSG_ROUTER] Native app not available on this device');
        }
        sendResponse({ isConnected: connected });
      } catch (error) {
        logger.error(`[MSG_ROUTER] Error connecting native port on demand: ${error.message || error}`);
        await _storage_js__WEBPACK_IMPORTED_MODULE_2__.storage.updateNativePortStatus(false);
        sendResponse({ isConnected: false });
      }
    })();
    return true; // Async response
  }

  /**
   * Handle RECONNECT_NATIVE_PORT action
   * @param {Function} sendResponse - Response callback
   * @returns {boolean}
   */
  handleReconnectNativePort(sendResponse) {
    (async () => {
      await _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.disconnect();
      _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.resetReconnectAttempts();
      _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.startReconnectionAttempts();
    })();
    sendResponse({ success: true, message: 'Reconnection started' });
    return true;
  }

  /** @param {{ logs?: string[] }} request */
  handleLogBatch(request, sendResponse) {
    const LOG_SERVER_URL = 'http://localhost:9900/log';
    const logs = Array.isArray(request.logs) ? request.logs : [];
    if (logs.length === 0) {
      sendResponse({ ok: true });
      return false;
    }
    const batchBody = logs.join('\n');
    fetch(LOG_SERVER_URL, {
      method: 'POST',
      body: batchBody,
      headers: { 'Content-Type': 'text/plain' }
    })
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  /**
   * Handle LAUNCH_VIDEO_URL action
   * @param {object} request - Request object
   * @param {object} sender - Sender object
   * @param {Function} sendResponse - Response callback
   * @returns {boolean}
   */
  handleLaunchVideoUrl(request, sender, sendResponse) {
    const tabId = sender.tab.id;
    this.currentVideoTabId = tabId;
    this.currentVideoMetadata = request.videoMetadata;
    this.currentVideoId = request.videoMetadata.id;

    // Resolve the (possibly async) manifest swap, then send to native. Respond
    // immediately below so the message channel isn't held open.
    (async () => {
      try {
        const meta = request.videoMetadata;

        // For HLS sites (Udemy) we ignore the page's <video> src (a blob:) and use the
        // .m3u8 manifest captured directly from the network for this tab. Sites with no
        // captured manifest (e.g. Coursera's progressive file) keep their original URL.
        if (meta) {
          const manifestUrl = await _manifestCapture_js__WEBPACK_IMPORTED_MODULE_3__.manifestCapture.getManifestForTab(tabId);
          if (manifestUrl) {
            logger.info('[MSG_ROUTER] Using captured HLS manifest for this tab');
            meta.videoUrl = manifestUrl;
          }
        }

        browserAPI.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const activeTabId = tabs[0]?.id || null;

          if (activeTabId === tabId) {
            logger.info('[MSG_ROUTER] Sending LAUNCH_VIDEO_URL to native app');
            // Print the final URL so it can be pasted into a browser to verify it plays.
            console.log('[LAUNCH] Video URL sent to native (copy to test in browser):\n' + meta.videoUrl);
            _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.sendMessage('LAUNCH_VIDEO_URL', meta);
          } else {
            logger.warn(`[MSG_ROUTER] Tab is not active, skipping video launch. Active tab: ${activeTabId} Video tab: ${tabId}`);
          }
        });
      } catch (e) {
        logger.error(`[MSG_ROUTER] Error in launching video: ${e.message || e}`);
      }
    })();

    sendResponse({ success: true });
    return true;
  }

  /**
   * Setup tab event listeners
   */
  setupTabListeners() {
    // If the tab in which the video is playing is closed, pause the video
    browserAPI.tabs.onRemoved.addListener((tabId) => {
      if (this.currentVideoTabId === '') {
        return;
      }

      if (tabId === this.currentVideoTabId) {
        logger.info('[MSG_ROUTER] Video tab closed, closing video');
        _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.sendMessage('CLOSE_VIDEO', {
          id: this.currentVideoId ? this.currentVideoId : '-'
        });
      }
    });

    // Handle tab activation
    browserAPI.tabs.onActivated.addListener((activeInfo) => {
      if (this.currentVideoTabId === '') {
        return;
      }

      if (this.currentVideoTabId === activeInfo.tabId) {
        logger.info('[MSG_ROUTER] Video tab activated, resuming video');
        _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.sendMessage('RESUME_VIDEO', {
          id: this.currentVideoId ? this.currentVideoId : '-'
        });
      } else {
        logger.info('[MSG_ROUTER] Different tab activated, pausing video');
        _nativePort_js__WEBPACK_IMPORTED_MODULE_0__.nativePort.sendMessage('PAUSE_VIDEO', {
          id: this.currentVideoId ? this.currentVideoId : '-'
        });

        // Send message to all tabs to pause videos
        browserAPI.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            (0,_utils_js__WEBPACK_IMPORTED_MODULE_4__.sendMessageToTabs)(tab.id, {
              action: "pauseAllVideos"
            });
          });
        });
      }
    });
  }
}

// Export singleton instance
const messageRouter = new MessageRouter();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (messageRouter);



/***/ }),

/***/ "./src/core/nativePort.js":
/*!********************************!*\
  !*** ./src/core/nativePort.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   nativePort: () => (/* binding */ nativePort)
/* harmony export */ });
/* harmony import */ var _storage_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./storage.js */ "./src/core/storage.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./logger.js */ "./src/core/logger.js");
/**
 * Native Port module for managing native messaging connection
 * Handles connect, disconnect, retry logic
 */




const logger = (0,_logger_js__WEBPACK_IMPORTED_MODULE_1__["default"])('NATIVE_PORT');

// Browser API compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

// Constants
const RECONNECT_DELAY_BASE = 1000; // Start with 1 second
const RECONNECT_DELAY_MAX = 30000; // Max 30 seconds
const CONNECTION_VERIFY_DELAY = 500; // Wait 500ms to verify connection
const MAX_RECONNECT_ATTEMPTS = 3;

/**
 * NativePort class for managing native messaging
 */
class NativePort {
  constructor() {
    this.port = null;
    this.isActuallyConnected = false;
    this.reconnectAttempts = 0;
    this.reconnectInterval = null;
    this.isReconnecting = false;
    this.healthCheckInterval = null;
  }

  /**
   * Initialize native port connection
   * 
   * This method creates a connection to the native desktop application.
   * It uses connection verification to ensure the connection is actually working.
   * 
   * Connection Verification Process:
   * 1. Create port object (this always succeeds, even if native app isn't running)
   * 2. Set up event listeners (onMessage, onDisconnect)
   * 3. Wait 500ms to verify connection is still alive
   * 4. If onDisconnect fires during verification → connection failed
   * 5. If still connected after 500ms → connection successful
   * 
   * Why verification is needed:
   * - browserAPI.runtime.connectNative() always returns a port object
   * - But if native app isn't running, onDisconnect fires immediately
   * - Without verification, we'd think we're connected when we're not
   * 
   * @returns {Promise<object|null>} Port object if connected, null if failed
   */
  async initialize() {
    try {
      
      // Step 1: Create connection to native application
      // This creates a port object, but doesn't guarantee connection is working
      // The native app must be running for this to actually work
      let port = browserAPI.runtime.connectNative('com.videoextractor.native');
      
      // Step 2: Set up verification flags
      // These track whether connection is verified and if it disconnected early
      let connectionVerified = false;        // True once we know connection works
      let disconnectedBeforeVerify = false;  // True if disconnected during verification
      let verificationTimeout = null;        // Timeout handle for verification delay

      // Step 3: Set up message listener
      // This fires when native app sends us a message
      // If we receive a message during verification, connection is definitely working
      port.onMessage.addListener((message) => {
        
        // If we receive a message, the connection is definitely working
        // Mark as verified immediately (no need to wait for timeout)
        if (!connectionVerified) {
          connectionVerified = true;
          this.isActuallyConnected = true;
          // Clear the verification timeout since we already know it's connected
          if (verificationTimeout) {
            clearTimeout(verificationTimeout);
          }
        }
      });

      // Step 4: Set up disconnect listener
      // This fires when native app closes, crashes, or connection is lost
      // It can fire immediately if native app isn't running (during verification)
      port.onDisconnect.addListener(async (error) => {
        // Clear port reference and connection status
        this.port = null;
        this.isActuallyConnected = false;
        
        // Clear verification timeout if it's still running
        if (verificationTimeout) {
          clearTimeout(verificationTimeout);
        }
        
        // Only update storage status if we're not in the verification phase
        // During verification, we just mark the flag and check it later
        // After verification, we immediately update storage
        if (connectionVerified) {
          // Connection was verified, then lost - update storage immediately
          await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
        } else {
          // Disconnected during verification - mark flag to check later
          disconnectedBeforeVerify = true;
        }
        
        // Get error message for logging
        const errorMessage = browserAPI.runtime.lastError ? browserAPI.runtime.lastError.message : 'Unknown error';
        logger.error(`[NATIVE_PORT] ✗ Native port disconnected. Error: ${errorMessage}`);

        // NOTE: We intentionally do NOT auto-start a reconnection loop here.
        // The native app is connected lazily (only while the user is on a configured
        // site — see contentScript.js), so a disconnect during verification just means
        // the app isn't installed/running on this device. Auto-reconnecting here would
        // repeatedly re-spawn the native process even where it doesn't exist.
        // Reconnection is driven on demand instead (CONNECT_NATIVE_PORT / sendMessage).
      });

      // Step 5: Wait to verify the connection is actually established
      // This is the key verification step!
      // 
      // Why wait 500ms?
      // - If native app isn't running, onDisconnect fires immediately (< 10ms)
      // - If native app is running, connection stays alive
      // - By waiting 500ms, we can tell the difference
      // 
      // If native host doesn't exist, onDisconnect will fire immediately
      // and set disconnectedBeforeVerify = true
      await new Promise((resolve) => {
        verificationTimeout = setTimeout(() => {
          resolve();
        }, CONNECTION_VERIFY_DELAY); // Wait 500ms
      });
      
      // Step 6: Check if port disconnected during verification
      // If disconnectedBeforeVerify is true, the connection failed
      // This means native app isn't running or connection was rejected
      if (disconnectedBeforeVerify) {
        const errorMessage = browserAPI.runtime.lastError ? browserAPI.runtime.lastError.message : 'Connection failed during verification';
        logger.error(`[NATIVE_PORT] ✗ Native port disconnected during verification. Error: ${errorMessage}`);
        this.isActuallyConnected = false;
        return null; // Return null to indicate failure
      }
      
      // Step 7: Check for runtime errors
      // Sometimes there are errors that don't trigger onDisconnect
      // Check browserAPI.runtime.lastError for any issues
      if (browserAPI.runtime.lastError) {
        const errorMessage = browserAPI.runtime.lastError.message;
        logger.error(`[NATIVE_PORT] ✗ Native port error during verification: ${errorMessage}`);
        this.isActuallyConnected = false;
        return null; // Return null to indicate failure
      }
      
      // Step 8: Connection verified successfully!
      // If we got here, the port is still connected after 500ms
      // This means the native app is running and connection is working
      connectionVerified = true;
      this.port = port; // Store the port instance for later use
      this.isActuallyConnected = true; // Mark as actually connected
      logger.info('[NATIVE_PORT] Native port connected successfully');
      
      // Reset reconnection state since we're now connected
      this.reconnectAttempts = 0; // Reset attempts on successful connection
      this.isReconnecting = false;
      
      return port; // Return port object to caller
    } catch (e) {
      logger.error(`[NATIVE_PORT] Error initializing native port: ${e.message || e}`);
      this.isActuallyConnected = false;
      _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
      return null;
    }
  }

  /**
   * Attempt reconnection with exponential backoff
   * 
   * This method tries to reconnect to the native app.
   * It uses exponential backoff to avoid hammering the connection.
   * 
   * Exponential Backoff:
   * - Attempt 1: Wait 1 second (1000ms)
   * - Attempt 2: Wait 2 seconds (2000ms)
   * - Attempt 3: Wait 4 seconds (4000ms)
   * - Max delay: 30 seconds
   * 
   * This prevents overwhelming the system with reconnection attempts.
   * 
   * @returns {Promise<void>}
   */
  async attemptReconnection() {
    // Prevent multiple simultaneous reconnection attempts
    if (this.isReconnecting) {
      return;
    }

    // Check if we've exceeded max attempts
    // After 3 failed attempts, stop trying (user can manually reconnect)
    if (this.reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
      this.stopReconnectionAttempts();
      return;
    }

    // Mark as reconnecting and increment attempt counter
    this.isReconnecting = true;
    this.reconnectAttempts++;
    
    // Calculate delay with exponential backoff
    // Formula: baseDelay * 2^(attempt-1), capped at maxDelay
    // Example: 1000 * 2^0 = 1000ms, 1000 * 2^1 = 2000ms, 1000 * 2^2 = 4000ms
    const delay = Math.min(RECONNECT_DELAY_BASE * Math.pow(2, this.reconnectAttempts - 1), RECONNECT_DELAY_MAX);

    try {
      // Wait for the calculated delay (exponential backoff)
      await new Promise(resolve => setTimeout(resolve, delay));
      
      // Try to initialize connection again
      const port = await this.initialize();
      
      // Check if connection was successful
      if (port && this.isActuallyConnected) {
        // Success! Update storage and reset state
        await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(true);
        logger.info('[NATIVE_PORT] Reconnection successful');
        this.reconnectAttempts = 0; // Reset counter
        this.isReconnecting = false;
        this.stopReconnectionAttempts(); // Stop periodic attempts
      } else {
        // Failed - will retry on next interval
        this.isReconnecting = false;
        // The interval will trigger the next attempt
      }
    } catch (e) {
      // Error during reconnection - log and reset state
      logger.error(`[NATIVE_PORT] ✗ Error during reconnection attempt: ${e.message || e}`);
      this.isActuallyConnected = false;
      this.isReconnecting = false;
      // The interval will trigger the next attempt
    }
  }

  /**
   * Start periodic reconnection attempts
   */
  startReconnectionAttempts() {
    if (this.reconnectInterval) {
      return;
    }

    this.reconnectInterval = setInterval(() => {
      // Check both if port exists AND if it's actually connected
      const isConnected = this.port !== null && this.isActuallyConnected;
      
      if (!isConnected && !this.isReconnecting) {
        this.attemptReconnection();
      } else if (isConnected) {
        this.stopReconnectionAttempts();
      }
    }, RECONNECT_DELAY_BASE * 2); // Check every 2 seconds
  }

  /**
   * Stop reconnection attempts
   */
  stopReconnectionAttempts() {
    if (this.reconnectInterval) {
      clearInterval(this.reconnectInterval);
      this.reconnectInterval = null;
    }
  }

  /**
   * Start health check interval
   */
  startHealthCheck() {
    if (this.healthCheckInterval) {
      return;
    }

    this.healthCheckInterval = setInterval(async () => {
      try {
        // Check both if port exists AND if it's actually connected
        if (this.port === null || !this.isActuallyConnected) {
          const isConnected = await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.isNativePortConnected();
          if (!isConnected && !this.isReconnecting) {
            this.startReconnectionAttempts();
          }
        } else {
          // Try to verify the port is still valid by checking for errors
          try {
            // Just check if we can access the port (this will throw if disconnected)
            if (this.port && browserAPI.runtime.lastError) {
              const error = browserAPI.runtime.lastError.message;
              if (error && (error.includes('native host') || error.includes('exited') || error.includes('disconnected'))) {
                this.port = null;
                this.isActuallyConnected = false;
                await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
                this.startReconnectionAttempts();
              }
            }
          } catch (e) {
            // Port might be disconnected
            this.port = null;
            this.isActuallyConnected = false;
            await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
            if (!this.isReconnecting) {
              this.startReconnectionAttempts();
            }
          }
        }
      } catch (e) {
        logger.error(`[HEALTH_CHECK] Error during health check: ${e.message || e}`);
      }
    }, 5000); // Check every 5 seconds
  }

  /**
   * Stop health check interval
   */
  stopHealthCheck() {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }

  /**
   * Send message to native port
   * 
   * This method sends a message to the native desktop application.
   * It handles reconnection automatically if the connection is lost.
   * 
   * Message Flow:
   * 1. Check if port is connected
   * 2. If not connected, try to reconnect
   * 3. Encode video metadata (base64)
   * 4. Send message via port.postMessage()
   * 5. Handle errors and retry if needed
   * 
   * @param {string} cmd - Command to send (e.g., 'LAUNCH_VIDEO_URL', 'PAUSE_VIDEO')
   * @param {object} data - Data to send (video metadata, etc.)
   * @param {number} retryCount - Current retry count (internal use)
   * @returns {Promise<void>}
   */
  async sendMessage(cmd, data, retryCount = 0) {
    const maxRetries = 3; // Maximum number of retry attempts
    
    try {
      // Step 1: Check if native port is connected before sending message
      // We check storage first to see the last known status
      const isConnected = await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.isNativePortConnected();
      
      if (!isConnected) {
        
        // Start reconnection attempts if not already running
        if (!this.isReconnecting && retryCount === 0) {
          this.startReconnectionAttempts();
        }
        
        // Try to reconnect immediately (don't wait for interval)
        // This gives faster response when user tries to use the feature
        if (!this.port && retryCount < maxRetries) {
          this.port = await this.initialize();
          
          if (this.port && this.isActuallyConnected) {
            // Reconnection successful - update status and retry message
            await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(true);
            // Retry sending the message (recursive call with incremented retry count)
            return this.sendMessage(cmd, data, retryCount + 1);
          }
        }
        
        // Couldn't reconnect - give up for now
        return;
      }

      if (!this.port) {
        this.port = await this.initialize();
        if (this.port && this.isActuallyConnected) {
          await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(true);
        } else {
          await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
          logger.error('[SEND_MSG] Failed to initialize native port');
          if (retryCount < maxRetries) {
            this.startReconnectionAttempts();
          }
          return;
        }
      }

      const encodedVideoMetadata = btoa(JSON.stringify(data));
      const payload = {
        ...data,
        videoMetadata: encodedVideoMetadata
      };
    
      const stringifiedPayload = JSON.stringify(payload);

      // Try to send the message
      try {
        logger.info(`[SEND_MSG] Sending command to native app: ${cmd}`);
        console.log('[SEND_MSG] Redirection payload sent to native port:', { cmd: cmd, data: stringifiedPayload });
        this.port.postMessage({ cmd: cmd, data: stringifiedPayload });
        logger.info(`[SEND_MSG] Command sent successfully: ${cmd}`);
      } catch (postError) {
        logger.error(`[SEND_MSG] ✗ Error posting message: ${postError.message || postError}`);
        // If postMessage fails, the port might be disconnected
        this.port = null;
        this.isActuallyConnected = false;
        await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
        
        if (retryCount < maxRetries) {
          this.startReconnectionAttempts();
          // Wait a bit and retry
          setTimeout(() => {
            this.sendMessage(cmd, data, retryCount + 1);
          }, 1000);
        }
      }
    } catch (e) {
      logger.error(`[SEND_MSG] ✗ Error sending message to native: ${e.message || e}`);
      const errorMessage = e.message || String(e);
      
      // Check if it's a native host error
      if (errorMessage.includes('native host') || errorMessage.includes('exited') || errorMessage.includes('disconnected')) {
        this.port = null;
        this.isActuallyConnected = false;
        await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
        
        if (retryCount < maxRetries) {
          this.startReconnectionAttempts();
          // Retry after a delay
          setTimeout(() => {
            this.sendMessage(cmd, data, retryCount + 1);
          }, 2000);
        }
      } else {
        this.isActuallyConnected = false;
        await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
      }
    }
  }

  /**
   * Check if port is connected
   * @returns {boolean}
   */
  isConnected() {
    return this.port !== null && this.isActuallyConnected;
  }

  /**
   * Get port instance
   * @returns {object|null}
   */
  getPort() {
    return this.port;
  }

  /**
   * Disconnect and reset port
   */
  async disconnect() {
    if (this.port) {
      try {
        this.port.disconnect();
      } catch (e) {
        logger.error(`[NATIVE_PORT] Error disconnecting port: ${e.message || e}`);
      }
      this.port = null;
    }
    this.isActuallyConnected = false;
    await _storage_js__WEBPACK_IMPORTED_MODULE_0__.storage.updateNativePortStatus(false);
  }

  /**
   * Reset reconnect attempts counter
   */
  resetReconnectAttempts() {
    this.reconnectAttempts = 0;
  }
}

// Export singleton instance
const nativePort = new NativePort();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (nativePort);



/***/ }),

/***/ "./src/core/storage.js":
/*!*****************************!*\
  !*** ./src/core/storage.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   storage: () => (/* binding */ storage)
/* harmony export */ });
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils.js */ "./src/core/utils.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./logger.js */ "./src/core/logger.js");
/**
 * Storage module for browser.storage operations
 * Handles all storage-related logic with safe operations
 */




const logger = (0,_logger_js__WEBPACK_IMPORTED_MODULE_1__["default"])('STORAGE');

const STORAGE_KEYS = {
  NATIVE_PORT_CONNECTED: 'nativePortConnected',
  HOST_PERMISSIONS: 'hostPermissions'
};

/**
 * Storage class for managing browser storage
 */
class Storage {
  /**
   * Update native port connection status
   * @param {boolean} isConnected - Connection status
   * @returns {Promise<void>}
   */
  async updateNativePortStatus(isConnected) {
    try {
      await (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.safeStorageSet)({ [STORAGE_KEYS.NATIVE_PORT_CONNECTED]: isConnected });
    } catch (e) {
      logger.error(`[STORAGE] Error updating native port status: ${e.message || e}`);
    }
  }

  /**
   * Check if native port is connected
   * @returns {Promise<boolean>}
   */
  async isNativePortConnected() {
    try {
      const result = await (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.safeStorageGet)(STORAGE_KEYS.NATIVE_PORT_CONNECTED);
      // Default to false if not set (safer approach - plugin disabled by default)
      return result[STORAGE_KEYS.NATIVE_PORT_CONNECTED] === true;
    } catch (e) {
      logger.error(`[STORAGE] Error checking native port status: ${e.message || e}`);
      return false;
    }
  }

  /**
   * Persist the list of configured sites (host permissions).
   * Stored on launch so it survives service-worker restarts and can be reused
   * without re-hitting the network.
   * @param {Array} hostPermissions
   * @returns {Promise<void>}
   */
  async setHostPermissions(hostPermissions) {
    try {
      await (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.safeStorageSet)({ [STORAGE_KEYS.HOST_PERMISSIONS]: hostPermissions || [] });
    } catch (e) {
      logger.error(`[STORAGE] Error saving host permissions: ${e.message || e}`);
    }
  }

  /**
   * Read the persisted list of configured sites (host permissions).
   * @returns {Promise<Array>} Stored host permissions, or [] if none.
   */
  async getHostPermissions() {
    try {
      const result = await (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.safeStorageGet)(STORAGE_KEYS.HOST_PERMISSIONS);
      return result[STORAGE_KEYS.HOST_PERMISSIONS] || [];
    } catch (e) {
      logger.error(`[STORAGE] Error reading host permissions: ${e.message || e}`);
      return [];
    }
  }

  async get(key) {
    try {
      const result = await (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.safeStorageGet)(key);
      return result[key];
    } catch (e) {
      return null;
    }
  }

  async set(key, value) {
    try {
      await (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.safeStorageSet)({ [key]: value });
    } catch (e) {
      throw e;
    }
  }
}

// Export singleton instance
const storage = new Storage();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (storage);



/***/ }),

/***/ "./src/core/utils.js":
/*!***************************!*\
  !*** ./src/core/utils.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   logError: () => (/* binding */ logError),
/* harmony export */   logInfo: () => (/* binding */ logInfo),
/* harmony export */   retryWithBackoff: () => (/* binding */ retryWithBackoff),
/* harmony export */   safeStorageGet: () => (/* binding */ safeStorageGet),
/* harmony export */   safeStorageSet: () => (/* binding */ safeStorageSet),
/* harmony export */   sendMessageToTabs: () => (/* binding */ sendMessageToTabs)
/* harmony export */ });
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./logger.js */ "./src/core/logger.js");
/**
 * Utilities layer for common operations
 * Provides safe storage operations, logging, and retry mechanisms
 */



// Browser API compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

const logger = (0,_logger_js__WEBPACK_IMPORTED_MODULE_0__["default"])('UTILS');

/**
 * Safely get data from browser storage
 * @param {string|string[]|object} keys - Key(s) to retrieve
 * @returns {Promise<object>} Storage data
 */
async function safeStorageGet(keys) {
  try {
    if (typeof browser !== 'undefined') {
      return await browser.storage.local.get(keys);
    } else {
      return await new Promise((resolve) => {
        chrome.storage.local.get(keys, resolve);
      });
    }
  } catch (e) {
    logger.error(`[UTILS] Error getting storage: ${e.message || e}`);
    return {};
  }
}

/**
 * Safely set data in browser storage
 * @param {object} data - Data to store
 * @returns {Promise<void>}
 */
async function safeStorageSet(data) {
  try {
    if (typeof browser !== 'undefined') {
      await browser.storage.local.set(data);
    } else {
      await new Promise((resolve) => {
        chrome.storage.local.set(data, resolve);
      });
    }
  } catch (e) {
    logger.error(`[UTILS] Error setting storage: ${e.message || e}`);
    throw e;
  }
}

/**
 * Log info message with prefix
 * @param {string} prefix - Log prefix (e.g., '[MODULE_NAME]')
 * @param {...any} args - Arguments to log
 */
function logInfo(prefix, ...args) {
  const logString = args.map(arg => {
    if (typeof arg === 'object') {
      return JSON.stringify(arg);
    }
    return String(arg);
  }).join(' ');
  logger.info(`${prefix} ${logString}`);
}

function logError(prefix, ...args) {
  const logString = args.map(arg => {
    if (typeof arg === 'object') {
      return JSON.stringify(arg);
    }
    return String(arg);
  }).join(' ');
  logger.error(`${prefix} ${logString}`);
}

/**
 * Retry a function with exponential backoff
 * @param {Function} fn - Async function to retry
 * @param {object} options - Retry options
 * @param {number} options.maxRetries - Maximum number of retries (default: 3)
 * @param {number} options.baseDelay - Base delay in ms (default: 1000)
 * @param {number} options.maxDelay - Maximum delay in ms (default: 30000)
 * @param {Function} options.onRetry - Callback called before each retry
 * @returns {Promise<any>} Result of the function
 */
async function retryWithBackoff(fn, options = {}) {
  const {
    maxRetries = 3,
    baseDelay = 1000,
    maxDelay = 30000,
    onRetry = null
  } = options;

  let lastError;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      
      if (attempt < maxRetries) {
        const delay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
        
        if (onRetry) {
          onRetry(attempt + 1, maxRetries, delay, error);
        }
        
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError;
}

/**
 * Send message to tabs (Firefox/Chrome compatible)
 * @param {number} tabId - Tab ID
 * @param {object} message - Message to send
 * @returns {Promise<any>}
 */
function sendMessageToTabs(tabId, message) {
  if (typeof browser !== 'undefined') {
    return browser.tabs.sendMessage(tabId, message).catch(() => {});
  } else {
    return new Promise((resolve) => {
      browserAPI.tabs.sendMessage(tabId, message, resolve);
    });
  }
}



/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!***************************!*\
  !*** ./src/background.js ***!
  \***************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/config.js */ "./src/core/config.js");
/* harmony import */ var _core_storage_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./core/storage.js */ "./src/core/storage.js");
/* harmony import */ var _core_messageRouter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core/messageRouter.js */ "./src/core/messageRouter.js");
/* harmony import */ var _core_manifestCapture_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./core/manifestCapture.js */ "./src/core/manifestCapture.js");
/* harmony import */ var _core_logger_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/logger.js */ "./src/core/logger.js");
/**
 * Background script - Main entry point
 *
 * Startup is intentionally lightweight: we DO NOT connect to the native app here.
 * Connecting spawns the native `AccBrowserVideoRed` process, which we only want to
 * happen when the user actually visits a configured site (see contentScript.js).
 *
 * On launch we only:
 *   1. Register message/tab listeners (synchronously)
 *   2. Mark the native port as disconnected (default state)
 *   3. Fetch + persist the plugin configuration (list of configured sites)
 *
 * The native connection is established lazily, on demand, when a content script on a
 * configured site sends CONNECT_NATIVE_PORT.
 *
 * @module background
 */







const logger = (0,_core_logger_js__WEBPACK_IMPORTED_MODULE_4__["default"])('BACKGROUND');

// Browser API compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

// Register message/tab listeners synchronously at top level so the service worker
// can wake on incoming events (content-script messages, tab switches, etc.).
_core_messageRouter_js__WEBPACK_IMPORTED_MODULE_2__.messageRouter.initialize();

// Observe Udemy network traffic to capture the HLS master playlist, so Udemy videos
// (whose <video> src is an unusable blob:) can be launched via their real .m3u8.
// Registered synchronously so the worker wakes for these requests.
_core_manifestCapture_js__WEBPACK_IMPORTED_MODULE_3__.manifestCapture.initialize();

/**
 * Runs on an actual browser/extension launch (onStartup / onInstalled).
 *
 * We deliberately do NOT connect to the native app here — connecting is deferred
 * until the user is on a configured site. This avoids spawning the native process
 * on every Chrome start and on devices where the native app isn't installed.
 *
 * @param {string} trigger - What triggered the launch (for logging)
 */
async function initializeOnLaunch(trigger) {
  try {
    logger.info(`[STARTUP] ${trigger}: initializing (lazy native-connection mode)...`);

    // Start from a known "disconnected" state. A live native connection cannot
    // survive a browser restart, so this is always correct on launch.
    await _core_storage_js__WEBPACK_IMPORTED_MODULE_1__.storage.updateNativePortStatus(false);

    // Fetch and persist configured sites. This is the only network work on launch.
    await _core_config_js__WEBPACK_IMPORTED_MODULE_0__.config.fetchPluginConfig();
    logger.info(`[STARTUP] Host permissions count: ${_core_config_js__WEBPACK_IMPORTED_MODULE_0__.config.getHostPermissions().length}`);

    logger.info('[STARTUP] ✓ Extension initialized (native app will start on demand)');
  } catch (e) {
    logger.error(`[STARTUP] ✗ Error during startup: ${e.message || e}`);
    await _core_storage_js__WEBPACK_IMPORTED_MODULE_1__.storage.updateNativePortStatus(false);
  }
}

// Fire on real launch signals.
browserAPI.runtime.onInstalled.addListener(() => initializeOnLaunch('onInstalled'));
browserAPI.runtime.onStartup.addListener(() => initializeOnLaunch('onStartup'));

// On every service-worker wake, make sure config is available (memory → storage →
// network only if nothing is cached). This never touches the native app.
_core_config_js__WEBPACK_IMPORTED_MODULE_0__.config.ensureLoaded().catch((e) => logger.error(`[STARTUP] ensureLoaded failed: ${e.message || e}`));

})();

/******/ })()
;
//# sourceMappingURL=background.js.map