/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/config/environment.js":
/*!***********************************!*\
  !*** ./src/config/environment.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const environment = {
    apiHost: 'https://docs.jiocloudpc.com/resources/dev/pluginconfigs.json', // Development API host
    xApiKey: 'eRjp5UKQxN84jYl4NHsCrav1OBI24a7P',
    isProduction: false
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (environment); 

/***/ }),

/***/ "./src/contentScript.css":
/*!*******************************!*\
  !*** ./src/contentScript.css ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/core/logger.js":
/*!****************************!*\
  !*** ./src/core/logger.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createLogger: () => (/* binding */ createLogger),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @env */ "./src/config/environment.js");


const browserAPI = typeof browser !== 'undefined' ? browser : (typeof chrome !== 'undefined' ? chrome : null);

class Logger {
  constructor(moduleName = 'APP') {
    this.appName = 'media redirection plugin';
    this.moduleName = moduleName;
    this.logServerUrl = 'http://localhost:9900/log';
    
    this.batchSize = 10;
    this.batchTimeout = 3000;
    this.logQueue = [];
    this.batchTimer = null;
    this.isBackground = typeof window === 'undefined' || typeof document === 'undefined';
    
    this.setupUnloadHandler();
  }

  getBrowser() {
    if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.getBrowserInfo) {
      return 'firefox';
    }
    if (typeof chrome !== 'undefined') {
      return 'chrome';
    }
    return 'unknown';
  }

  getEnvironment() {
    try {
      return _env__WEBPACK_IMPORTED_MODULE_0__["default"].isProduction ? 'production' : 'development';
    } catch (err) {
      return 'unknown';
    }
  }

  getFormattedDateTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
  }

  formatLog(level, logString) {
    const dateTime = this.getFormattedDateTime();
    const browser = this.getBrowser();
    const env = this.getEnvironment();
    
    return `[${dateTime}] [${level}] [${this.appName}] [${env}] [${logString}] [${browser}]`;
  }

  setupUnloadHandler() {
    if (typeof window !== 'undefined') {
      window.addEventListener('beforeunload', () => {
        this.flushBatch();
      });
      
      if (typeof document !== 'undefined') {
        document.addEventListener('visibilitychange', () => {
          if (document.hidden) {
            this.flushBatch();
          }
        });
      }
    }
    
    if (browserAPI && browserAPI.runtime && browserAPI.runtime.onSuspend) {
      browserAPI.runtime.onSuspend.addListener(() => {
        this.flushBatch();
      });
    }
  }

  addToBatch(logString) {
    this.logQueue.push(logString);
    
    if (this.logQueue.length >= this.batchSize) {
      this.flushBatch();
      return;
    }
    
    if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.flushBatch();
      }, this.batchTimeout);
    }
  }

  flushBatch() {
    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = null;
    }
    
    if (this.logQueue.length === 0) {
      return;
    }
    
    const batch = this.logQueue.slice();
    this.logQueue = [];
    
    this.sendBatchToServer(batch);
  }

  sendBatchToServer(logBatch) {
    if (this.isBackground) {
      this.fetchToLogServer(logBatch);
    } else {
      this.forwardToBackground(logBatch);
    }
  }

  fetchToLogServer(logBatch) {
    try {
      const batchBody = logBatch.join('\n');
      fetch(this.logServerUrl, {
        method: 'POST',
        body: batchBody,
        headers: { 'Content-Type': 'text/plain' }
      }).catch(() => {});
    } catch (err) {}
  }

  forwardToBackground(logBatch) {
    try {
      if (browserAPI && browserAPI.runtime && browserAPI.runtime.sendMessage) {
        browserAPI.runtime.sendMessage(
          { action: 'LOG_BATCH', logs: logBatch }
        ).catch(() => {});
      }
    } catch (err) {}
  }

  sendToServer(logString) {
    this.addToBatch(logString);
  }

  info(logString) {
    const formattedLog = this.formatLog('INFO', logString);
    this.sendToServer(formattedLog);
  }

  error(logString) {
    const formattedLog = this.formatLog('ERROR', logString);
    this.sendToServer(formattedLog);
  }

  warn(logString) {
    const formattedLog = this.formatLog('WARN', logString);
    this.sendToServer(formattedLog);
  }

  debug(logString) {
    const formattedLog = this.formatLog('DEBUG', logString);
    this.sendToServer(formattedLog);
  }
}

function createLogger(appName) {
  return new Logger(appName);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (createLogger);


/***/ }),

/***/ "./src/websiteHandler.js":
/*!*******************************!*\
  !*** ./src/websiteHandler.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _core_logger_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/logger.js */ "./src/core/logger.js");


const logger = (0,_core_logger_js__WEBPACK_IMPORTED_MODULE_0__["default"])('WEBSITE_HANDLER');

const websiteHandlers = {
	'default': {
		getVideoUrl: (element) => {
			return element.currentSrc || element.src;
		},

		getAllVideosAndIframes: (root = document) => {
			let elements = [];
			if (root instanceof Node) {
				elements.push(...root.getElementsByTagName('video'));
				const iframes = root.getElementsByTagName('iframe');
				elements.push(...iframes);
			} else {
				logger.error(`Invalid root node: ${JSON.stringify(root)}`);
			}
			return elements;
		}
	},
	'embibe': {
		getVideoUrl: (element) => {
			if (element.tagName.toLowerCase() === 'video') {
				return element.getAttribute('data-cdn-response');
			} else {
				return element.currentSrc || element.src;
			}
		},

		getAllVideosAndIframes: (root = document) => {
			let elements = [];
			if (root instanceof Node) {
				const videosWithDataCdnResponse = root.querySelectorAll('video[data-cdn-response]');
				elements.push(...Array.from(videosWithDataCdnResponse));
				elements.push(...root.getElementsByTagName('iframe'));
			} else {
				logger.error(`Invalid root node: ${JSON.stringify(root)}`);
			}
			return elements;
		}
	}
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (websiteHandlers);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./src/contentScript.js ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _contentScript_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contentScript.css */ "./src/contentScript.css");
/* harmony import */ var _websiteHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./websiteHandler */ "./src/websiteHandler.js");
/* harmony import */ var _core_logger_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core/logger.js */ "./src/core/logger.js");




const logger = (0,_core_logger_js__WEBPACK_IMPORTED_MODULE_2__["default"])('CONTENT_SCRIPT');

logger.info('Plugin 0.2.2 loaded');

// Add browser API compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

let websites = [];
let currentWebsite = null; // The configured site matched for the current URL (null if none)
let nativePortConnected = false; // Cache the connection status

// Initialize previousUrl with current URL on load
let previousUrl = window.location.href;
let urlCheckInterval = null;
let isProcessingUrl = false; // Flag to prevent concurrent processing

// Throttling for checkNativePortStatus
let isCheckingPort = false;
let lastErrorLogTime = 0;
const ERROR_LOG_THROTTLE_MS = 5000; // Only log error once per 5 seconds
const PORT_STATUS_CACHE_TTL = 5000; // Cache port status for 5 seconds
let lastPortStatusCheck = -PORT_STATUS_CACHE_TTL; // Initialize to ensure first check always happens

// Whether the background captured a directly-playable stream URL (.m3u8) for this tab.
// Gates the play overlay for blob-based streaming sites (e.g. Udemy): no captured stream
// → no overlay. Updated by GET_MANIFEST_STATUS queries and MANIFEST_UPDATED pushes.
const MANIFEST_STATUS_CACHE_TTL = 1500; // Cache manifest status for 1.5s
let manifestAvailable = false;
let lastManifestCheck = -MANIFEST_STATUS_CACHE_TTL;

// Read-only check of the native port connection status.
// This NEVER asks the background to connect/reconnect (that would spawn the native
// process on every page). It only reports the last-known status. To actually connect,
// use ensureNativeConnected() — and only on a configured site.
async function checkNativePortStatus(forceCheck = false) {
  const now = Date.now();

  // Return cached value if it's still fresh and not forcing a check
  if (!forceCheck && (now - lastPortStatusCheck) < PORT_STATUS_CACHE_TTL) {
    return nativePortConnected;
  }

  // Prevent concurrent calls
  if (isCheckingPort) {
    return nativePortConnected;
  }

  isCheckingPort = true;

  try {
    const response = await new Promise((resolve, reject) => {
      browserAPI.runtime.sendMessage({ action: "CHECK_NATIVE_PORT_STATUS" }, (response) => {
        if (browserAPI.runtime.lastError) {
          reject(new Error(browserAPI.runtime.lastError.message));
        } else if (response && response.error) {
          reject(new Error(response.error));
        } else {
          resolve(response);
        }
      });
    });
    const wasConnected = nativePortConnected;
    nativePortConnected = response && response.isConnected === true;
    lastPortStatusCheck = now; // Update cache timestamp

    if (nativePortConnected && !wasConnected) {
      logger.info('[PORT] Native port connection established');
    } else if (!nativePortConnected && wasConnected) {
      logger.warn('[PORT] Native port connection lost');
    }

    isCheckingPort = false;
    return nativePortConnected;
  } catch (error) {
    const nowErr = Date.now();
    if (nowErr - lastErrorLogTime > ERROR_LOG_THROTTLE_MS) {
      logger.error(`[PORT] ✗ Error checking native port status: ${error.message || error}`);
      lastErrorLogTime = nowErr;
    }
    nativePortConnected = false;
    lastPortStatusCheck = nowErr; // Update cache timestamp even on error
    isCheckingPort = false;
    return false;
  }
}

// Lazily establish the native port connection.
// This is the ONLY place that asks the background to spawn/connect the native app,
// so it must only be called when the current URL matches a configured site.
// Returns true if connected (native app available), false otherwise.
async function ensureNativeConnected() {
  if (nativePortConnected) {
    return true;
  }

  try {
    const response = await new Promise((resolve, reject) => {
      browserAPI.runtime.sendMessage({ action: "CONNECT_NATIVE_PORT" }, (response) => {
        if (browserAPI.runtime.lastError) {
          reject(new Error(browserAPI.runtime.lastError.message));
        } else if (response && response.error) {
          reject(new Error(response.error));
        } else {
          resolve(response);
        }
      });
    });

    nativePortConnected = response && response.isConnected === true;
    lastPortStatusCheck = Date.now();

    if (nativePortConnected) {
      logger.info('[PORT] Native port connection established (on demand)');
    } else {
      logger.debug('[PORT] Native app not available on this device');
    }
    return nativePortConnected;
  } catch (error) {
    const now = Date.now();
    if (now - lastErrorLogTime > ERROR_LOG_THROTTLE_MS) {
      logger.error(`[PORT] ✗ Error connecting native port: ${error.message || error}`);
      lastErrorLogTime = now;
    }
    nativePortConnected = false;
    lastPortStatusCheck = Date.now();
    return false;
  }
}

// Ask the background whether it has captured a directly-playable stream URL (.m3u8) for
// this tab. Cached briefly to avoid chatter; also pushed by the background via
// MANIFEST_UPDATED when a new one is captured.
async function refreshManifestStatus(force = false) {
  const now = Date.now();
  if (!force && (now - lastManifestCheck) < MANIFEST_STATUS_CACHE_TTL) {
    return manifestAvailable;
  }
  try {
    const response = await new Promise((resolve, reject) => {
      browserAPI.runtime.sendMessage({ action: "GET_MANIFEST_STATUS" }, (response) => {
        if (browserAPI.runtime.lastError) {
          reject(new Error(browserAPI.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    });
    manifestAvailable = !!(response && response.hasManifest);
    lastManifestCheck = now;
  } catch (error) {
    // Leave the previous value on error.
  }
  return manifestAvailable;
}

async function getPluginConfig() {
  try {
    const response = await new Promise((resolve, reject) => {
      browserAPI.runtime.sendMessage({ action: "FETCH_PLUGIN_CONFIG" }, (response) => {
        if (browserAPI.runtime.lastError) {
          reject(new Error(browserAPI.runtime.lastError.message));
        } else if (response && response.error) {
          reject(new Error(response.error));
        } else {
          resolve(response);
        }
      });
    });

    if (response && response.host_permissions) {
      // Replace (don't accumulate) so repeated calls can't create duplicates.
      websites = [...response.host_permissions];
      logger.info(`[CONFIG] Plugin config fetched successfully, websites count: ${websites.length}`);
    } else {
      logger.warn('[CONFIG] No host_permissions in response');
    }
  } catch (error) {
    logger.error(`[CONFIG] Error fetching plugin config: ${error.message || error}`);
  }
}

let allOverlays = [];
let mediaMonitorInterval = null;
let mediaPreventHandlers = null;

function pauseAllVideos() {
  const elements = _websiteHandler__WEBPACK_IMPORTED_MODULE_1__["default"]["default"].getAllVideosAndIframes();
  elements.forEach(element => {
    if (element.tagName.toLowerCase() === 'video' && !element.paused) {
      element.pause();
    }
  });
}

function pauseAllMedia() {
  // Pause all video elements
  const videos = document.querySelectorAll('video');
  videos.forEach(video => {
    if (!video.paused) {
      video.pause();
    }
    video.muted = true;
  });

  // Pause all audio elements
  const audios = document.querySelectorAll('audio');
  audios.forEach(audio => {
    if (!audio.paused) {
      audio.pause();
    }
    audio.muted = true;
  });

  // Pause all iframes (YouTube videos, etc.)
  const iframes = document.querySelectorAll('iframe');
  iframes.forEach(iframe => {
    try {
      iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
    } catch (e) {
      // Cross-origin iframe, can't access
    }
  });

  // Also use the existing handler
  const elements = _websiteHandler__WEBPACK_IMPORTED_MODULE_1__["default"]["default"].getAllVideosAndIframes();
  elements.forEach(element => {
    if (element.tagName.toLowerCase() === 'video') {
      if (!element.paused) {
        element.pause();
      }
      element.muted = true;
    } else if (element.tagName.toLowerCase() === 'iframe') {
      try {
        element.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
      } catch (e) {
        // Cross-origin iframe
      }
    }
  });
}

function startMediaMonitoring() {
  // Clear any existing interval
  if (mediaMonitorInterval) {
    clearInterval(mediaMonitorInterval);
  }

  // Monitor and pause media every 500ms while overlay is active
  mediaMonitorInterval = setInterval(() => {
    pauseAllMedia();
  }, 500);
}

function stopMediaMonitoring() {
  if (mediaMonitorInterval) {
    clearInterval(mediaMonitorInterval);
    mediaMonitorInterval = null;
  }
}

function getAllVideosAndIframes(root = document) {
  let videos = [];

  // Get direct videos only
  if (root instanceof Node) {
    videos.push(...root.getElementsByTagName('video'));

    // Get iframes that might contain YouTube videos
    const iframes = root.getElementsByTagName('iframe');
    videos.push(...iframes);
    /*for (const iframe of iframes) {
      if (isYoutubeIframe(iframe)) {
        videos.push(iframe);
      }
    }*/
  }
  return videos;
}

// Resolve an element's effective media source. Coursera (and others) render a
// <video> with <source> children and no src attribute, so element.src is '' even
// though the video is playable. Fall back to currentSrc and any <source> child so
// overlays are created/shown for these players.
function getElementSource(element) {
  if (!element) {
    return '';
  }
  if (element.tagName && element.tagName.toLowerCase() === 'video') {
    if (element.currentSrc) {
      return element.currentSrc;
    }
    if (element.src) {
      return element.src;
    }
    const source = element.querySelector && element.querySelector('source[src]');
    return source ? source.getAttribute('src') : '';
  }
  return element.src || '';
}

// Whether we can hand native a URL it can actually play for this element:
//  - YouTube launches via the page URL (resolved at click time)          → yes
//  - a direct http(s) file URL in the element (e.g. Coursera)             → yes
//  - a blob:/empty src (e.g. Udemy HLS) is only usable if the background
//    captured a stream URL (.m3u8) from the network for this tab          → manifestAvailable
// Streams we can't capture (DRM, session-bound, etc.) stay non-redirectable,
// so the play overlay is never shown for them.
function isRedirectable(element, website) {
  // Only sites flagged for stream capture (e.g. Udemy) are gated. Every other platform
  // (YouTube, Embibe, Khan, …) is unaffected and always passes.
  if (!website || !website.requiresStreamCapture) {
    return true;
  }
  const handler = _websiteHandler__WEBPACK_IMPORTED_MODULE_1__["default"][website.handler || 'default'];
  const url = (handler.getVideoUrl(element) || getElementSource(element) || '');
  if (/^https?:\/\//i.test(url)) {
    return true;
  }
  return manifestAvailable;
}

async function checkOverlays() {
  // Check native port connection status before processing
  if (!await checkNativePortStatus()) {
    return;
  }

  const website = includesWebsite(window.location.href);
  if (website && website.is_pip) {
    //console.log('Checking overlays');

    // Streaming sites (e.g. Udemy) gate the overlay on a captured stream URL. Other
    // platforms are untouched — no manifest query, no gating.
    if (website.requiresStreamCapture) {
      await refreshManifestStatus();
    }

    const elements = _websiteHandler__WEBPACK_IMPORTED_MODULE_1__["default"][website.handler || 'default'].getAllVideosAndIframes();
    //console.log('Elements: ', elements);

    for (let element of elements) {
      //console.log('Checking element: ', element);
      //if (!(element.parentElement.querySelector('.video-overlay') || element.parentElement.querySelector('.iframe-overlay'))) {
      if ((element.parentElement.querySelector('.iframe-overlay') == null && isYoutubeIframe(element) && getElementSource(element) !== '')) {
        createOverlay(element, website);
      }
      else if (element.parentElement.querySelector('.video-overlay') == null && element.tagName.toLowerCase() === 'video' && getElementSource(element) !== '' && isRedirectable(element, website)) {
        createOverlay(element, website);
      }
    }
  }
}

function isYoutubeIframe(iframe) {
  const src = iframe.src || '';
  return (src.includes('https://www.youtube') || src.includes('https://www.youtu.be')) && src.includes('embed');
}

async function processVideosAndIframes(website) {
  // Check native port connection status before processing
  if (!await checkNativePortStatus()) {
    return;
  }
  // Streaming sites (e.g. Udemy) gate the overlay on a captured stream URL. Other
  // platforms are untouched — no manifest query, no gating.
  if (website && website.requiresStreamCapture) {
    await refreshManifestStatus();
  }

  updateAllOverlays();

  const elements = _websiteHandler__WEBPACK_IMPORTED_MODULE_1__["default"][website.handler || 'default'].getAllVideosAndIframes();

  for (const element of elements) {
    if (!element.id) {
      element.id = Date.now().toString();
    }

    if (element.tagName.toLowerCase() === 'video') {
      element.pause();
      //let videoUrl = element.currentSrc || element.src;
      createOverlay(element, website);
    } else if (element.tagName.toLowerCase() === 'iframe' && isYoutubeIframe(element) && getElementSource(element) !== '') {
      createOverlay(element, website);
    }
  }
}

const updateAllOverlays = () => {
  const website = includesWebsite(window.location.href);
  allOverlays = allOverlays.filter(([element, overlay]) => {
    // For stream-capture sites (e.g. Udemy) only: drop the overlay if this element can
    // no longer be handed to native (e.g. a blob stream whose .m3u8 we couldn't capture).
    if (website && website.requiresStreamCapture && element.tagName.toLowerCase() === 'video' && !isRedirectable(element, website)) {
      try { overlay.remove(); } catch (e) { /* ignore */ }
      return false;
    }

    if (getElementSource(element) === '') {
      overlay.style.display = 'none';
    } else {
      overlay.style.display = 'flex';
    }

    if (element.tagName.toLowerCase() === 'video') {
      element.pause();
    } else {
      try {
        element.contentWindow.postMessage('{"event":"command","func":"' + 'pauseVideo' + '","args":""}', '*')
      } catch (e) {
      }
    }

    const rect = element.getBoundingClientRect();
    //overlay.style.width = `${rect.width}px`;
    //overlay.style.height = `${rect.height}px`;

    if (element.tagName.toLowerCase() === 'video') {
      overlay.style.width = `${element.clientWidth}px`;
      overlay.style.height = `${element.clientHeight}px`;
    } else if (element.tagName.toLowerCase() === 'iframe') {
      overlay.style.width = `100%`;
      overlay.style.height = `100%`;
    }

    //overlay.style.top = `${rect.top + window.scrollY}px`;
    //overlay.style.left = `${rect.left + window.scrollX}px`;
    overlay.style.top = 0;
    overlay.style.left = 0;
    return true;
  });
};

function createOverlay(element, website) {
  const overlay = document.createElement('div');
  overlay.className = element.tagName.toLowerCase() === 'iframe' ? 'iframe-overlay' : 'video-overlay';
  overlay.style.position = 'absolute';
  overlay.style.zIndex = '1000';
  overlay.style.display = 'flex';

  const updateOverlaySize = () => {
    if (getElementSource(element) === '') {
      overlay.style.display = 'none';
    } else {
      overlay.style.display = 'flex';
    }

    if (element.tagName.toLowerCase() === 'video') {
      element.pause();
    }

    const rect = element.getBoundingClientRect();
    //overlay.style.width = `100%`;
    //overlay.style.height = `100%`;

    if (element.tagName.toLowerCase() === 'video') {
      overlay.style.width = `${element.clientWidth}px`;
      overlay.style.height = `${element.clientHeight}px`;
    } else if (element.tagName.toLowerCase() === 'iframe') {
      overlay.style.width = `100%`;
      overlay.style.height = `100%`;
    }

    //overlay.style.top = `${rect.top + window.scrollY}px`;
    //overlay.style.left = `${rect.left + window.scrollX}px`;
    overlay.style.top = 0;
    overlay.style.left = 0;
  };

  const playButton = document.createElement('img');
  playButton.className = 'show-details-btn';
  playButton.src = browserAPI.runtime.getURL('icons/play.png');
  playButton.style.cssText = 'width: 100px !important; background: transparent !important;';
  playButton.addEventListener('click', async () => {
    let videoUrl = _websiteHandler__WEBPACK_IMPORTED_MODULE_1__["default"][website.handler || 'default'].getVideoUrl(element);
    let metadata = {
      videoUrl: videoUrl,
      id: element.id,
      ...website,
    };

    if (element.tagName.toLowerCase() === 'video') {
      if (isYoutubePage()) {
        metadata.videoUrl = window.location.href;
      }
      metadata = {
        ...metadata,
        duration: element.duration,
        currentTime: element.currentTime,
        paused: element.paused,
        volume: element.volume,
        muted: element.muted,
        playbackRate: element.playbackRate,
        videoWidth: element.videoWidth,
        videoHeight: element.videoHeight,
        mute: 0
      };
    }

    logger.info(`[OVERLAY] Play button clicked, video URL: ${videoUrl}`);
    playVideo(metadata);
  });

  overlay.appendChild(playButton);
  //document.body.appendChild(overlay);

  element.parentElement.style.position = 'relative';
  element.parentElement.style.zIndex = '10000';
  element.parentElement.appendChild(overlay);
  updateOverlaySize();

  allOverlays.push([element, overlay]);

  return overlay;
}

async function createRedirectOverlay(website) {
  // Check if overlay already exists
  const existingOverlay = document.querySelector('.redirect-overlay');
  if (existingOverlay) {
    existingOverlay.remove();
    stopMediaMonitoring();
    if (mediaPreventHandlers) {
      document.removeEventListener('play', mediaPreventHandlers, true);
      document.removeEventListener('playing', mediaPreventHandlers, true);
      mediaPreventHandlers = null;
    }
  }
  
  // Check native port connection status before creating redirect overlay
  const portStatus = await checkNativePortStatus();
  if (!portStatus) {
    return null;
  }

  // Remove all scripts from head
  const scripts = document.getElementsByTagName('script');
  while (scripts.length > 0) {
    scripts[0].parentNode.removeChild(scripts[0]);
  }

  // Clear body content
  //document.body.innerHTML = '';
  await processVideosAndIframes(website);

  // Pause all media before showing overlay
  pauseAllMedia();

  const overlay = document.createElement('div');
  overlay.classList.add('redirect-overlay');

  //<img class="loader" src="${chrome.runtime.getURL('icons/loader.svg')}" />
  overlay.innerHTML = `
    <div class="heading">Launching ${website.name}</div>

    <div class="f12-container">
      <div class="button-outer">
        <div class="button-inner">
          <div class="button-text">F12</div>
        </div>
      </div>
      <div class="f12-text">
        Press <b>F12</b> to come back to JioPC
      </div>
    </div>

    <div class="subheading">Please wait while the page loads. <br> If it doesn't load, <span class="link">click here to try again.</span></div>
  `;

  const link = overlay.querySelector('.link');

  link.addEventListener('click', async () => {
    playVideo({
      videoUrl: window.location.href,
      ...website,
    });
  });

  document.body.appendChild(overlay);

  // Start monitoring to prevent media from playing
  startMediaMonitoring();

  // Add event listeners to prevent media playback
  const preventPlay = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.target) {
      e.target.pause();
      e.target.muted = true;
    }
  };

  document.addEventListener('play', preventPlay, true);
  document.addEventListener('playing', preventPlay, true);
  
  // Store handlers for cleanup
  mediaPreventHandlers = preventPlay;

  // Verify overlay is in DOM
  const verifyOverlay = document.querySelector('.redirect-overlay');
  if (!verifyOverlay) {
    logger.error('[REDIRECT_OVERLAY] ERROR: Overlay not found in DOM after creation');
  } else {
    logger.info(`[REDIRECT_OVERLAY] Overlay created successfully for website: ${website.name}`);
  }

  //allOverlays.push([element, overlay]);
  return overlay;
}

function deleteRedirectOverlay() {
  const overlay = document.querySelector('.redirect-overlay');
  if (overlay) {
    overlay.remove();
  }
  
  // Stop media monitoring when overlay is removed
  stopMediaMonitoring();
  
  // Remove event listeners
  if (mediaPreventHandlers) {
    document.removeEventListener('play', mediaPreventHandlers, true);
    document.removeEventListener('playing', mediaPreventHandlers, true);
    mediaPreventHandlers = null;
  }
}

// Centralized function to handle URL changes
async function handleUrlChange(currentUrl, source = 'UNKNOWN') {
  // Prevent concurrent processing
  if (isProcessingUrl) {
    return;
  }

  // Skip if URL hasn't actually changed
  if (currentUrl === previousUrl) {
    return;
  }

  isProcessingUrl = true;

  try {
    previousUrl = currentUrl;

    // Tear down overlays left over from the previous page
    allOverlays.forEach(([element, overlay]) => {
      try {
        if (element && element.parentElement && overlay) {
          element.parentElement.removeChild(overlay);
        }
      } catch (e) {
        logger.error(`[URL_CHANGE:${source}] Error removing overlay: ${e.message || e}`);
      }
    });
    allOverlays = [];
    deleteRedirectOverlay();

    // Make sure we have the site config to match against
    if (websites.length === 0) {
      await getPluginConfig();
    }

    // Step 1: Does this URL match a configured site?
    const website = includesWebsite(currentUrl);
    currentWebsite = website || null;

    // Not a configured site → do nothing, and never touch the native app.
    if (!website) {
      logger.debug(`[URL_CHANGE:${source}] No website matched for URL`);
      return;
    }

    // Step 2: Configured site → now (and only now) try to reach the native app.
    // This is what spawns the native process, and only on a matching site.
    const connected = await ensureNativeConnected();
    if (!connected) {
      // Native app not installed / not reachable on this device → no overlay.
      logger.debug(`[URL_CHANGE:${source}] Native app unavailable, skipping: ${website.name}`);
      return;
    }

    // Step 3: Native app is available → run the redirection / overlay logic.
    if (!website.is_pip) {
      logger.info(`[URL_CHANGE:${source}] Website matched (redirect mode): ${website.name}`);
      await createRedirectOverlay(website);
      await playVideo({
        videoUrl: currentUrl,
        ...website,
      });
    } else {
      logger.info(`[URL_CHANGE:${source}] Website matched (pip mode): ${website.name}`);
      await processVideosAndIframes(website);
    }
  } catch (error) {
    logger.error(`[URL_CHANGE:${source}] ✗ Error in URL change handler: ${error.message || error}`);
  } finally {
    isProcessingUrl = false;
  }
}

const observer = new MutationObserver(() => {
  // Detect SPA URL changes cheaply on every mutation (plain string compare).
  const currentUrl = window.location.href;
  if (currentUrl !== previousUrl) {
    handleUrlChange(currentUrl, 'MUTATION_OBSERVER');
    return;
  }

  // Only maintain overlays on a configured site with a live native connection.
  // On non-matching pages we do nothing here — no messaging, no native access.
  if (!currentWebsite || !nativePortConnected) {
    return;
  }

  debounce([updateAllOverlays, checkOverlays], 100);
});

// Observe both regular DOM and shadow DOM changes
observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Initialize on page load
async function initializeOnPageLoad() {
  const currentUrl = window.location.href;

  // If the URL differs from what we last processed, treat it as a URL change.
  if (currentUrl !== previousUrl) {
    await handleUrlChange(currentUrl, 'INIT');
    return;
  }

  // Make sure we have the site config to match against
  if (websites.length === 0) {
    await getPluginConfig();
  }

  // Step 1: Does this URL match a configured site?
  const website = includesWebsite(currentUrl);
  currentWebsite = website || null;

  // Not a configured site → nothing to do; never touch the native app.
  if (!website) {
    return;
  }

  // Step 2: Configured site → connect on demand; bail out if the app isn't there.
  const connected = await ensureNativeConnected();
  if (!connected) {
    return;
  }

  // Step 3: Native app available → run the redirection / overlay logic.
  const existingOverlay = document.querySelector('.redirect-overlay');
  if (!website.is_pip && !existingOverlay) {
    await createRedirectOverlay(website);
    await playVideo({
      videoUrl: currentUrl,
      ...website,
    });
  } else if (website.is_pip) {
    await processVideosAndIframes(website);
  }
}

// Run initialization when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    initializeOnPageLoad();
    startUrlChecker();
  });
} else {
  // DOM already loaded
  initializeOnPageLoad();
  startUrlChecker();
}

// Also handle page unload to clean up
window.addEventListener('beforeunload', () => {
  stopUrlChecker();
  stopMediaMonitoring();
});

// Also listen for page visibility changes (when user navigates back)
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    // Trigger a check after a short delay to ensure page is fully loaded
    setTimeout(() => {
      const currentUrl = window.location.href;
      if (currentUrl !== previousUrl) {
        handleUrlChange(currentUrl, 'VISIBILITY');
      } else {
        // Even if URL didn't change, check if overlay needs to be created
        initializeOnPageLoad();
      }
    }, 500);
  }
});

// Listen for popstate (back/forward navigation)
window.addEventListener('popstate', () => {
  setTimeout(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== previousUrl) {
      handleUrlChange(currentUrl, 'POPSTATE');
    } else {
      initializeOnPageLoad();
    }
  }, 100);
});

// Listen for pushstate/replacestate (programmatic navigation)
const originalPushState = history.pushState;
const originalReplaceState = history.replaceState;

history.pushState = function(...args) {
  originalPushState.apply(history, args);
  setTimeout(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== previousUrl) {
      handleUrlChange(currentUrl, 'PUSHSTATE');
    }
  }, 100);
};

history.replaceState = function(...args) {
  originalReplaceState.apply(history, args);
  setTimeout(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== previousUrl) {
      handleUrlChange(currentUrl, 'REPLACESTATE');
    }
  }, 100);
};

// Periodic URL checker as a fallback (checks every 1 second)
function startUrlChecker() {
  // Clear any existing interval
  if (urlCheckInterval) {
    clearInterval(urlCheckInterval);
  }
  
  urlCheckInterval = setInterval(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== previousUrl && !isProcessingUrl) {
      handleUrlChange(currentUrl, 'PERIODIC_CHECK');
    }
  }, 1000);
  
}

// Stop the periodic checker (if needed in future)
function stopUrlChecker() {
  if (urlCheckInterval) {
    clearInterval(urlCheckInterval);
    urlCheckInterval = null;
  }
}

async function playVideo(videoMetadata) {
  // Ensure the native app is connected before launching (connects on demand if needed).
  const connected = await ensureNativeConnected();
  if (!connected) {
    return;
  }

  videoMetadata.id = Date.now().toString();
  logger.info(`[PLAY_VIDEO] Launching video: ${videoMetadata.videoUrl} Website: ${videoMetadata.name}`);
  browserAPI.runtime.sendMessage({ action: "LAUNCH_VIDEO_URL", videoMetadata }, (response) => {
    if (browserAPI.runtime.lastError) {
      logger.error(`[PLAY_VIDEO] Error sending message: ${browserAPI.runtime.lastError.message || browserAPI.runtime.lastError}`);
    } else {
      logger.info('[PLAY_VIDEO] Video launch request sent successfully');
    }
  });
}

browserAPI.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "pauseAllVideos") {
    pauseAllVideos();
    sendResponse({ success: true });
  } else if (request.action === "MANIFEST_UPDATED") {
    // Background captured a playable stream URL (.m3u8) for this tab → allow the overlay.
    manifestAvailable = true;
    lastManifestCheck = Date.now();
    checkOverlays();
  }
  return false;
});

let canExecute = true;
function debounce(funcs, wait) {
  if (!canExecute) {
    return;
  }

  funcs.forEach(func => func());
  canExecute = false;
  setTimeout(() => canExecute = true, wait);
}

function isYoutubePage() {
  return (window.location.href.includes('https://www.youtube'));
}

function includesWebsite(url) {
  const matched = websites.find(website => url.startsWith(website.url));
  return matched;
}
})();

/******/ })()
;
//# sourceMappingURL=contentScript.js.map